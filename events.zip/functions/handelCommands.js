const { REST } = require("@discordjs/rest");
const { Routes } = require('discord-api-types/v9');
const fs = require('fs');
const config = require('../config.js');

const clientId = config.ClientBot; 
const guildId = config.GuildId;

module.exports = (client) => {
    client.handleCommands = async (commandFolders, path) => {
        client.commandArray = [];
        for (folder of commandFolders) {
            const commandFiles = fs.readdirSync(`${path}/${folder}`).filter(file => file.endsWith('.js'));
            for (const file of commandFiles) {
                const command = require(`../commands/${folder}/${file}`);

            if (file === 'ip.js' && !config.IP) continue;
            if (file === 'start-giveaway.js' && !config.Giveaway) continue;
            if (file === 'end-giveaway.js' && !config.Giveaway) continue;
            if (file === 'reroll-giveaway.js' && !config.Giveaway) continue;
            if (file === 'playtime.js' && !config.PlayTime) continue;
            if (file === 'rps.js' && !config.Rps) continue;
            if (file === 'clear.js' && !config.Clear) continue;
            if (file === 'reset-all-playtime.js' && !config.PlayTime) continue;
            if (file === 'reset-playtime.js' && !config.PlayTime) continue;
            if (file === 'feedback.js' && !config.Feedback) continue;
            if (file === 'guess-the-number.js' && !config.GuussTheNumber) continue;
            if (file === 'play.js' && !config.MusicPlay) continue;
            if (file === 'paybox-cal.js' && !config.PayBox) continue;
            if (file === 'paypal-cal.js' && !config.PayPal) continue;
            if (file === 'tictactoe.js' && !config.Tictactoc) continue;
            if (file === 'stats.js' && !config.Stats) continue;
            if (file === 'setup-verify.js' && !config.Verify) continue;
            if (file === 'setup-ticket.js' && !config.TicketSystem) continue;
            if (file === 'add-claims.js' && !config.ClaimsTicket) continue;
            if (file === 'remove-claims.js' && !config.ClaimsTicket) continue;
            if (file === 'reset-claims.js' && !config.ClaimsTicket) continue;
            if (file === 'reset-all-claims.js' && !config.ClaimsTicket) continue;
            if (file === 'set-timeout.js' && !config.TimeoutTicket) continue;
            if (file === 'remove-timeout.js' && !config.TimeoutTicket) continue;
            if (file === 'add-category.js' && !config.TicketSystem) continue;
            if (file === 'remove-category.js' && !config.TicketSystem) continue;
            if (file === 'setup-suggestion.js' && !config.Suggestion1) continue;
            if (file === 'setup-welcome.js' && !config.Welcome) continue;
            if (file === 'setup-boosts.js' && !config.Boosts) continue;
            if (file === 'setup-logs.js' && !config.MainLogs) continue;
            if (file === 'search-player.js' && !config.SearchPlayerCommand) continue;
            if (file === 'setup-bugreport.js' && !config.BugReport) continue;
            if (file === 'setup-ip.js' && !config.IP) continue;
            if (file === 'avatar.js' && !config.Avatar) continue;
            if (file === 'server-info.js' && !config.ServerInfo) continue;
            if (file === 'user-info.js' && !config.UserInfo) continue;
            if (file === 'unlock-channel.js' && !config.UnLockChannel) continue;
            if (file === 'lock-channel.js' && !config.LockChannel) continue;
            if (file === 'say.js' && !config.Say11) continue;
            if (file === 'say-embed.js' && !config.Say22) continue;
            if (file === 'setup-xp.js' && !config.Xp) continue;
            if (file === 'xp.js' && !config.Xp) continue;
            if (file === 'add-xp.js' && !config.Xp) continue;
            if (file === 'remove-xp.js' && !config.Xp) continue;
            if (file === 'reset-xp.js' && !config.Xp) continue;
            if (file === 'reset-all-xp.js' && !config.Xp) continue;
            if (file === 'xp-leaderboard.js' && !config.Xp) continue;
            if (file === 'blacklist.js' && !config.Blacklist) continue;
            if (file === 'setup-shop.js' && !config.XpShop) continue;
            if (file === 'ticket-stats.js' && !config.TicketStats) continue;

                client.commands.set(command.data.name, command);
                client.commandArray.push(command.data.toJSON());
            }
        }

        const rest = new REST({
            version: '9'
        }).setToken(config.TokenBot);

        (async () => {
            try {
                await rest.put(
                    Routes.applicationCommands(clientId), {
                        body: client.commandArray
                    },
                );
            } catch (error) {
                console.error(error);
            }
        })();
    };
};