const { SlashCommandBuilder, EmbedBuilder } = require('@discordjs/builders');
const fs = require('fs');
const path = require('path');
const config = require('../../config.js');
const { SimpleContextFetchingStrategy } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('playtime')
        .setDescription('Check Playtime a user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select a User')
                .setRequired(true)),
    async execute(interaction) {
        const user = interaction.options.getUser('user');

        const playtimeFilePath = path.join(__dirname, '../../../playtime.json');

        const playtimeData = JSON.parse(fs.readFileSync(playtimeFilePath, 'utf-8'));

        const totalMinutes = playtimeData[user.id] || 0;

        const days = Math.floor(totalMinutes / 1440);
        const hours = Math.floor((totalMinutes % 1440) / 60);
        const minutes = totalMinutes % 60;

        const embed = new EmbedBuilder()
        .setTitle(`${user.username}'s Playtime `)
        .setColor(config.ServerColor2)
        .setDescription(`${user} - \`${days} Days, ${hours} Hours, ${minutes} Minutes\``)
        .setThumbnail(config.ServerIcon)
        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
        .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },
};
