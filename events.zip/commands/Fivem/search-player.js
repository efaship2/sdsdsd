const { SlashCommandBuilder } = require('@discordjs/builders');
const { CommandInteraction, EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch');
const config = require('../../config.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('search-player')
        .setDescription(`[Admin] Search Player`)
        .addStringOption(option =>
            option.setName('id')
                .setDescription('ID Player')
                .setRequired(true)
        ),
    /**
     * 
     * @param {CommandInteraction} interaction 
     */
    async execute(interaction) {
        if (!interaction.member.roles.cache.has(config.ManagementRoleID)) {
            return interaction.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**`, ephemeral: true });
        }
        const playerId = interaction.options.getString('id');

        const url = `http://${config.FivemAddressIP}:${config.FivemPort}/players.json`;

        try {
            const response = await fetch(url);
            if (!response.ok) {
                return interaction.reply({ content: 'לא ניתן להשיג מידע על השרת / השרת מכובה.', ephemeral: true });
            }
            
            const players = await response.json();
            const player = players.find(p => p.id.toString() === playerId);

            if (!player) {
                return interaction.reply({ content: 'שחקן על ID הזה לא נמצא.', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setTitle(`\`🔎\` Search Player (\`${player.name}\`)`)
                .addFields(
                    { name: 'Name', value: `**${player.name}**`, inline: true },
                    { name: 'ID', value: `**${player.id.toString()}**`, inline: true },
                    { name: 'Ping', value: `**${player.ping.toString()}**`, inline: true },
                    { 
                        name: 'Discord Tag', 
                        value: player.identifiers.find(id => id.startsWith('discord:'))
                            ? `<@${player.identifiers.find(id => id.startsWith('discord:')).replace('discord:', '')}>`
                            : 'לא נמצא', 
                        inline: true 
                    },
                    { 
                        name: 'Discord ID', 
                        value: player.identifiers.find(id => id.startsWith('discord:'))
                            ? `**${player.identifiers.find(id => id.startsWith('discord:')).replace('discord:', '')}**`
                            : 'לא נמצא', 
                        inline: true 
                    },
                    { name: 'Steam', value: `||**${player.identifiers.find(id => id.startsWith('steam:'))}**||` || 'לא נמצא', inline: true },
                    { name: 'Fivem', value: `||**${player.identifiers.find(id => id.startsWith('fivem:'))}**||` || 'לא נמצא', inline: true },
                    { name: 'Live', value: `||**${player.identifiers.find(id => id.startsWith('live:'))}**||` || 'לא נמצא', inline: true },
                    { name: 'Xbl', value: `||**${player.identifiers.find(id => id.startsWith('xbl:'))}**||` || 'לא נמצא', inline: true },
                    { name: 'License', value: `||**${player.identifiers.find(id => id.startsWith('license:'))}**||` || 'לא נמצא', inline: false },
                    { name: 'License 2', value: `||**${player.identifiers.find(id => id.startsWith('license2:'))}**||` || 'לא נמצא', inline: false },
                )
                .setTimestamp()
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setColor(config.ServerColor);

            interaction.reply({ embeds: [embed] });
        } catch (error) {
            interaction.reply({ content: 'שגיאה בעת ניסיון למשוך את המידע.', ephemeral: true });
        }
    },
};