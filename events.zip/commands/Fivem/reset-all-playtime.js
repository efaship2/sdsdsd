const fs = require('fs');
const { SlashCommandBuilder } = require('@discordjs/builders');
const config = require('../../config.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reset-all-playtime')
        .setDescription('[Admin] Reset All Playtime/Top10'),
    
    async execute(interaction) {
        if (!interaction.member.roles.cache.has(config.ManagementRoleID)) {
            return interaction.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**`, ephemeral: true });
        }
        const filePath = './playtime.json';

        const defaultData = {};

        fs.writeFile(filePath, JSON.stringify(defaultData, null, 2), (err) => {
            if (err) {
                console.error('Error writing to file', err);
                return;
            }

            return interaction.reply({ content: '**Reset All PlayTime/Top10**', ephemeral: true });
        });
    },
};