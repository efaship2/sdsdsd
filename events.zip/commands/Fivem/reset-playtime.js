const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../../config.js');

const playtimeFilePath = path.join(__dirname, '../../../playtime.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reset-playtime')
    .setDescription('[Admin] Reset Playtime')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('User')
        .setRequired(true)
    ),
  
  async execute(interaction) {
    if (!interaction.member.roles.cache.has(config.ManagementRoleID)) {
        return interaction.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**`, ephemeral: true });
    }

    const user = interaction.options.getUser('user');
    const userId = user.id;

    let playtimeData;
    try {
      playtimeData = JSON.parse(fs.readFileSync(playtimeFilePath, 'utf8'));
    } catch (error) {
      return interaction.reply({ content: 'Error', ephemeral: true });
    }

    if (!playtimeData[userId]) {
      return interaction.reply({ content: `${user} אין לו זמן בתוך השרת.`, ephemeral: true });
    }

    playtimeData[userId] = 0;

    try {
      fs.writeFileSync(playtimeFilePath, JSON.stringify(playtimeData, null, 2), 'utf8');
    } catch (error) {
      return interaction.reply({ content: 'Error', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(config.ServerColor2)
      .setTitle(`${user.username} Playtime `)
      .setDescription(`**Successfully Reset The Playtime For ${user}.**`)
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};