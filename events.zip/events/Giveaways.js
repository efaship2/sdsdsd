const { ActionRowBuilder } = require('@discordjs/builders');
const { ButtonBuilder, ButtonStyle, Events, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const giveawaysFilePath = path.join(__dirname, '../../giveaways.json');

module.exports = {
  name: Events.ClientReady,
  once: false,

  async execute(client) {
    setInterval(async () => {
      if (!fs.existsSync(giveawaysFilePath)) return;

      const giveaways = JSON.parse(fs.readFileSync(giveawaysFilePath));
      const currentTime = Date.now();

      for (const [messageID, giveaway] of Object.entries(giveaways)) {
        if (currentTime >= giveaway.time && !giveaway.giveawayEnd) {
          const channel = await client.channels.fetch(config.GiveawayChannelId);
          if (!channel) continue;

          const giveawayMessage = await channel.messages.fetch(messageID).catch(() => null);
          if (giveawayMessage) {
            const winners = selectWinners(giveaway.membersJoins, giveaway.amount);
            giveaway.giveawayWinner = winners;

            const button = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setURL(`https://discord.com/channels/${config.GuildId}/${config.GiveawayChannelId}/${messageID}`)
                .setLabel('Link To Giveaway')
                .setStyle(ButtonStyle.Link)
            );

            const messageContent = `\`🎉\` **Congratulations** ${winners.map(winner => `<@${winner}>`).join(', ')}**!** **You Won __${giveaway.prize}__!**`;

            const updatedEmbed = new EmbedBuilder()
            .setDescription(`\`🪁\` **This Giveaway Has Ended.**\n\n**Ended:** <t:${parseInt(Date.now() / 1000)}:R> (<t:${parseInt(Date.now() / 1000)}>)\n**Hosted By:** <@${giveaway.hostedby}>\n**Entries:** ${giveaway.membersJoins.length + giveaway.amount}\n**Winners:** ${winners.map(winner => `<@${winner}>`).join(', ')}`)
            .setTitle(`__${giveaway.prize}__`)
            .setColor('Red')
            .setThumbnail(config.ServerIcon)
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp();

            const button22 = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
              .setCustomId('join_giveaway')
              .setLabel('Enter Giveaway')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true),
            new ButtonBuilder()
              .setCustomId('leave_giveaway')
              .setLabel('Leave Giveaway')
              .setStyle(ButtonStyle.Danger)
              .setDisabled(true),
            new ButtonBuilder()
              .setCustomId('show_participants')
              .setLabel('Participants')
              .setEmoji('<:Member2:1292951804895563917>')
              .setStyle(ButtonStyle.Secondary)
          );

          await giveawayMessage.edit({ embeds: [updatedEmbed], components: [button22] });
          await channel.send({ content: messageContent, components: [button] });

            giveaway.giveawayEnd = true;
            fs.writeFileSync(giveawaysFilePath, JSON.stringify(giveaways, null, 2));
          }
        }
      }
    }, 20000);

    client.on('interactionCreate', async interaction => {
      if (!interaction.isButton()) return;

      const giveaways = JSON.parse(fs.readFileSync(giveawaysFilePath));
      const giveaway = giveaways[interaction.message.id];
      if (!giveaway) return;

      if (interaction.customId === 'join_giveaway') {
        if (giveaway.membersJoins.includes(interaction.user.id)) {
          return interaction.reply({ content: '**You Are Already In The Giveaway.**', ephemeral: true });
        }

        giveaway.membersJoins.push(interaction.user.id);
        fs.writeFileSync(giveawaysFilePath, JSON.stringify(giveaways, null, 2));
        await interaction.reply({ content: '**You Have Successfully Joined The Giveaway.**', ephemeral: true });

      } else if (interaction.customId === 'leave_giveaway') {
        if (!giveaway.membersJoins.includes(interaction.user.id)) {
          return interaction.reply({ content: '**You Are Not In The Giveaway.**', ephemeral: true });
        }

        giveaway.membersJoins = giveaway.membersJoins.filter(id => id !== interaction.user.id);
        fs.writeFileSync(giveawaysFilePath, JSON.stringify(giveaways, null, 2));
        await interaction.reply({ content: '**You Have Successfully Left The Giveaway.**', ephemeral: true });

      } else if (interaction.customId === 'show_participants') {
        if (giveaway.membersJoins.length === 0) {
            return interaction.reply({ content: '**There Are No Participants.**', ephemeral: true });
        }
    
        const participantsData = await Promise.all(
            giveaway.membersJoins.map(async memberID => {
                const user = await client.users.fetch(memberID).catch(() => null);
                return user ? `<@${memberID}> ${user.username} \`(${memberID})\`` : `<@${memberID}> \`(${memberID})\``;
            })
        );
    
        const winnersDisplay = giveaway.giveawayWinner && giveaway.giveawayWinner.length > 0
            ? await Promise.all(giveaway.giveawayWinner.map(async (winnerID) => {
                const winner = await client.users.fetch(winnerID).catch(() => null);
                return winner ? `<@${winnerID}> ${winner.username} \`(${winnerID})\`` : `<@${winnerID}> \`(${winnerID})\``;
            })).then(winnerData => winnerData.join('\n'))
            : 'Giveaway Not End';
    
        const participantsEmbed = new EmbedBuilder()
            .setAuthor({ name: `${config.ServerName}`, iconURL: config.ServerIcon })
            .setTitle('Participants')
            .setDescription(`__**Winners:**__ \n ${winnersDisplay}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n${participantsData.join('\n')}`)
            .setColor('#ffbc49')
            .setTimestamp();
    
        await interaction.reply({ embeds: [participantsEmbed], ephemeral: true });
    }        
    });
  }
};

function selectWinners(members, amount) {
  if (members.length === 0) return [];

  const winners = [];
  while (winners.length < amount && members.length > 0) {
    const randomIndex = Math.floor(Math.random() * members.length);
    winners.push(members.splice(randomIndex, 1)[0]);
  }
  return winners;
}