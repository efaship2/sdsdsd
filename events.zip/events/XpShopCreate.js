const fs = require('fs');
const shopData = require('../../xpShopData.json');
const config = require('../config.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;
        if (!config.XpShop) return;

        const userId = interaction.user.id;
        const buttonId = interaction.customId;

        if (!buttonId.startsWith('buy_')) return;

        const roleIndex = parseInt(buttonId.split('_')[1], 10);
        const roleName = Object.keys(shopData)[roleIndex];
        const roleData = shopData[roleName];
        const member = interaction.guild.members.cache.get(userId);

        let xpLevels;
        try {
            xpLevels = JSON.parse(fs.readFileSync('./xpLevels.json', 'utf8'));
        } catch (error) {
            console.error('Failed to read xpLevels.json', error);
            return;
        }

        if (!xpLevels[userId]) {
            return interaction.reply({ content: 'You do not have enough xp to buy this item.', ephemeral: true });
        }

        const role = interaction.guild.roles.cache.get(roleData.id);
        if (!role) {
            return interaction.reply({ content: 'Role not found.', ephemeral: true });
        }

        if (member.roles.cache.has(role.id)) {
            return interaction.reply({ content: `You already own the <@&${roleData.id}>.`, ephemeral: true });
        }

        const userXp = xpLevels[userId].xp;
        const xpNeededForRole = roleData.cost;

        if (userXp < xpNeededForRole) {
            return interaction.reply({ content: `You do not have enough xp to buy this item.`, ephemeral: true });
        }

        let remainingXp = userXp - xpNeededForRole;

        xpLevels[userId].xp = remainingXp;

        try {
            fs.writeFileSync('./xpLevels.json', JSON.stringify(xpLevels, null, 2), 'utf8');
        } catch (error) {
            console.error('Failed to update xpLevels.json', error);
            return;
        }

        await member.roles.add(role);

        return interaction.reply({ content: `You’ve successfully purchased the <@&${roleData.id}>.`, ephemeral: true });
    },
};
