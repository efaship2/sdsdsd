const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ActivityType } = require('discord.js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const serverIp = `${config.FivemAddressIP}:${config.FivemPort}`;
const channelId = config.PlayerListChannelId;
const messageIdFile = path.join(__dirname, '../../PlayerListMessageId.txt');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        if (!config.PlayerList) {
            return;
        }

        updatePlayerList(client);
        setInterval(() => updatePlayerList(client), 20000);
    }
};

async function updatePlayerList(client) {
    if (!config.PlayerList) {
        return;
    }

    const channel = await client.channels.fetch(channelId);
    const guild = client.guilds.cache.get(config.GuildId);

    let messageId = null;
    if (fs.existsSync(messageIdFile)) {
        messageId = fs.readFileSync(messageIdFile, 'utf8').trim();
    }

    try {
        const response = await axios.get(`http://${serverIp}/players.json`);
        const response2 = await axios.get(`http://${serverIp}/info.json`);
        const players = response.data;
        const maxPlayers = response2.data.vars ? response2.data.vars.sv_maxClients : 'Unknown';

        const playerCount = players.length;

        const percentage = maxPlayers !== 'Unknown' ? Math.round((playerCount / maxPlayers) * 100) : 'Unknown';

        const playerInfo = await Promise.all(
            players.map(async (player) => {
                const name = player.name || 'Unknown';
                const serverId = player.id ? `[ID: \`${player.id}\`]` : 'Unknown';

                const discordId = player.identifiers.find(id => id.startsWith('discord:'));
                const discordTag = discordId
                    ? `<@${discordId.split(':')[1]}>`
                    : 'Not Found';

                let staffTag = '';
                if (discordId) {
                    const discordUserId = discordId.split(':')[1];
                    const member = await guild.members.fetch(discordUserId).catch(() => null);
                    if (member && member.roles.cache.has(config.StaffRoleId)) {
                        staffTag = ' (Staff)';
                    }
                }

                return `${serverId} | \`${name}\` | ${discordTag}${staffTag}`;
            })
        );

        const embedStatus = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${config.ServerName} | Server Status`, iconURL: config.ServerIcon })
            .setTitle(
                `\`🟢\` **Status: ONLINE**\n` +
                `\`🎮\` **Players: ${playerCount}/${maxPlayers}**\n` +
                `\`🌍\` **Space: ${percentage}%**`,
            )
            .setDescription(`**__Online Players:__**\n${playerInfo.join('\n') || 'None Players'}`)
            .setThumbnail(config.ServerIcon)
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp();

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('label111')
                .setLabel(`Players: ${playerCount}/${maxPlayers}`)
                .setDisabled(true)
                .setStyle(ButtonStyle.Success)
            );

        client.user.setActivity(`(${playerCount}/${maxPlayers}) | ${guild.memberCount}`, { type: ActivityType.Watching });

        if (!messageId) {
            const message = await channel.send({ embeds: [embedStatus], components: [button] });
            fs.writeFileSync(messageIdFile, message.id);
        } else {
                const message = await channel.messages.fetch(messageId);
                await message.edit({ embeds: [embedStatus], components: [button] });
        }
    } catch (error) {
        const embedOfflineStatus = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${config.ServerName} | Server Status`, iconURL: config.ServerIcon })
            .setTitle(
                `\`🔴\` **Status: OFF**\n` +
                `\`🎮\` **Players: OFF**\n` +
                `\`🌍\` **Space: OFF**`,
            )
            .setThumbnail(config.ServerIcon)
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp();

        const buttonOffline = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('label111')
                .setLabel(`Server Is Offline`)
                .setDisabled(true)
                .setStyle(ButtonStyle.Danger)
            );

        client.user.setActivity(`(OFF) | ${guild.memberCount}`, { type: ActivityType.Watching });

        if (!messageId) {
            const message = await channel.send({ embeds: [embedOfflineStatus], components: [buttonOffline] });
            fs.writeFileSync(messageIdFile, message.id);
        } else {
                const message = await channel.messages.fetch(messageId);
                await message.edit({ embeds: [embedOfflineStatus], components: [buttonOffline] });
        }
    }
}