const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.js');

const channelId22222 = config.StaffOnlineTop10ChannelId;
const messageIdFile = path.join(__dirname, '../../StaffOnlineTop10MessageId.txt');
const requiredRoleId = config.StaffRoleId;

function formatTime(minutes) {
    const days = Math.floor(minutes / 1440);
    const hours = Math.floor((minutes % 1440) / 60);
    const mins = minutes % 60;
    return `${days} Days, ${hours} Hours, ${mins} Minutes`;
}

async function updateLeaderboard(client) {
    if (!config.StaffOnlineTop10) {
        return;
    }
    
    const guild = client.guilds.cache.get(config.GuildId);
    if (!guild) {
        console.error(`Guild with ID ${config.GuildId} not found.`);
        return;
    }
    
    const data = JSON.parse(fs.readFileSync('./playtime.json'));
    const leaderboard = [];

    for (const [userId, minutes] of Object.entries(data)) {
        const member = await guild.members.fetch(userId).catch(() => null);
        
        if (member && member.roles.cache.has(requiredRoleId)) {
            leaderboard.push({ userId, time: formatTime(minutes) });
        }
    }

    leaderboard.sort((a, b) => b.time.localeCompare(a.time)).slice(0, 10);

    if (leaderboard.length === 0) {
        return;
    }

    const description = leaderboard.map((entry, index) => `\`${index + 1}.\` <@${entry.userId}> \`${entry.time}\``).join('\n');
    
    const embed = new EmbedBuilder()
        .setTitle(`\`🏆\` ${config.ServerName} | Staff Online Top 10`)
        .setDescription(description)
        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
        .setThumbnail(config.ServerIcon)
        .setTimestamp()
        .setColor(config.ServerColor);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('check_playtime')
                .setLabel('Check Your Playtime')
                .setEmoji(`⭐`)
                .setStyle(ButtonStyle.Primary)
        );

    const channel = client.channels.cache.get(channelId22222);
    let messageId = null;
    if (fs.existsSync(messageIdFile)) {
        messageId = fs.readFileSync(messageIdFile, 'utf8').trim();
    }

    if (channel) {
        if (messageId) {
            const message = await channel.messages.fetch(messageId);
            if (message) {
                await message.edit({ embeds: [embed], components: [row] });
            } else {
                const newMessage = await channel.send({ embeds: [embed], components: [row] });
                fs.writeFileSync(messageIdFile, newMessage.id);
            }
        } else {
            const newMessage = await channel.send({ embeds: [embed], components: [row] });
            fs.writeFileSync(messageIdFile, newMessage.id);
        }
    }
}

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        if (!config.StaffOnlineTop10) {
            return;
        }
        updateLeaderboard(client);
        setInterval(() => updateLeaderboard(client), 20000);
    }
};