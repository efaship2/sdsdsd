const fs = require('fs');
const path = require('path');

const invitesPath = path.join(__dirname, '../../invites.json');
const inviteCountPath = path.join(__dirname, '../../inviteCount.json');

function loadInvites() {
    if (!fs.existsSync(invitesPath)) {
        fs.writeFileSync(invitesPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(invitesPath, 'utf8'));
}

function saveInvites(invites) {
    fs.writeFileSync(invitesPath, JSON.stringify(invites, null, 2));
}

function loadInviteCounts() {
    if (!fs.existsSync(inviteCountPath)) {
        fs.writeFileSync(inviteCountPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(inviteCountPath, 'utf8'));
}

function saveInviteCounts(counts) {
    fs.writeFileSync(inviteCountPath, JSON.stringify(counts, null, 2));
}

module.exports = {
    name: 'inviteCreate',
    async execute(invite) {
        const invites = loadInvites();

        if (!invites[invite.code]) {
            invites[invite.code] = { creator: invite.inviter.id, uses: invite.uses || 0 };
            saveInvites(invites);
        }
    },
};
