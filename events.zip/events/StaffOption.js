const { Interaction, Embed } = require("discord.js");
const { ChannelType, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle, PermissionsBitField, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const config = require('../config.js')

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'button:staff-option') {
        if (
            !interaction.member.roles.cache.some(
                role => role.id === `${config.StaffRoleId}` || role.id === `${config.ManagementRoleID}`
            )
        ) {
            return await interaction.reply({
                content: `**You Do Not Have The Required Permissions To Use This Button.**`,
                ephemeral: true
            });
        }

            const staffembed = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setDescription(`**Hello ${interaction.user}, Welcome To The Staff Ticket Menu.**`)

            const staffbuttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('button:option1')
                    .setLabel('Add User')
                    .setStyle(ButtonStyle.Primary)
            )
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('button:option2')
                        .setLabel('Remove User')
                        .setStyle(ButtonStyle.Primary)
                )
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('button:option5')
                        .setLabel('Rename')
                        .setStyle(ButtonStyle.Primary)
                )
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('button:ticket-close')
                        .setLabel('Close')
                        .setStyle(ButtonStyle.Danger)
                )
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('button:option3')
                        .setLabel('Save Ticket')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.reply({ embeds: [staffembed], components: [staffbuttons], ephemeral: true });
        } else if (interaction.customId === 'button:option1') {
            const modal = new ModalBuilder()
                .setCustomId('modal:option1')
                .setTitle('Add User to Ticket')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('user-id')
                            .setLabel('Enter User ID')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('User ID')
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        } else if (interaction.customId === 'button:option2') {
            const modal = new ModalBuilder()
                .setCustomId('modal:option2')
                .setTitle('Remove User from Ticket')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('user-id')
                            .setLabel('Enter User ID')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('User ID')
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        } else if (interaction.customId === 'button:option5') {
            const modal = new ModalBuilder()
                .setCustomId('modal:option5')
                .setTitle('Rename Ticket')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('new-name')
                            .setLabel('Enter New Ticket Name')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('New Ticket Name')
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        } else if (interaction.customId === 'button:ticket-close') {
        if (
            !interaction.member.roles.cache.some(
                role => role.id === `${config.StaffRoleId}` || role.id === `${config.ManagementRoleID}`
            )
        ) {
            return await interaction.reply({
                content: `**You Do Not Have The Required Permissions To Use This Button.**`,
                ephemeral: true
            });
        }
        
            const modal = new ModalBuilder()
                .setCustomId('modal:ticket-reason')
                .setTitle('Close Ticket')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('reason')
                            .setLabel('Reason')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(false)
                    )
                );
        
            await interaction.showModal(modal);
        
            const modalSubmission = await interaction.awaitModalSubmit({
                filter: (i) => i.customId === 'modal:ticket-reason' && i.user.id === interaction.user.id,
                time: 60000
            }).catch(() => null);
        
            const reason = modalSubmission.fields.getTextInputValue('reason');
            await modalSubmission.deferUpdate();
        
            let timeRemaining = 5000;
            const embed22 = new EmbedBuilder()
                .setColor('Red')
                .setDescription(`**The Ticket Will Be Deleted In \`${timeRemaining / 1000}\` Seconds!**`);
            
            const closeMessage = await interaction.channel.send({ embeds: [embed22] });
        
            const intervalId = setInterval(async () => {
                timeRemaining -= 1000;
                if (timeRemaining <= 0) {
                    clearInterval(intervalId);
                } else {
                    const updatedEmbed = new EmbedBuilder()
                        .setColor('Red')
                        .setDescription(`**The Ticket Will Be Deleted In \`${timeRemaining / 1000}\` Seconds!**`);
                    await closeMessage.edit({ embeds: [updatedEmbed] });
                }
            }, 1000);
        
            const timeoutId = setTimeout(async () => {
                const firstMessage = await interaction.channel.messages.fetch({ limit: 1, after: 0 });
                const firstContent = firstMessage.first()?.content;
                const userMentionMatch = firstContent?.match(/<@!?(\d+)>/);
        
                if (userMentionMatch) {
                    const userId = userMentionMatch[1];
                    const user = await client.users.fetch(userId);
        
                    const { createTranscript } = require('discord-html-transcripts');
                    const transcript = await createTranscript(interaction.channel, {
                        limit: -1,
                        returnBuffer: false,
                        fileName: `${interaction.channel.name}.html`
                    });
        
                    const embedclose11 = new EmbedBuilder()
                        .setColor(config.ServerColor)
                        .setTitle(`Your Ticket Closed`)
                        .addFields(
                            { name: `Ticket Closed Reason`, value: `${reason || 'No Reason'}`, inline: true },
                            { name: `Ticket Closed By`, value: `${interaction.user}`, inline: true },
                            { name: `Ticket Closed At`, value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true }
                        )
                        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                        .setTimestamp();
        
                    try {
                        await user.send({
                            embeds: [embedclose11],
                            files: [transcript]
                        });
                    } catch (error) {
                        console.error('Error sending DM to user:', error);
                    }
                }
        
                try {
                    await interaction.channel.delete();
                } catch (error) {
                    console.error('Error deleting the channel:', error);
                }
            }, 5000);
        }        
        }
    }
    
    
