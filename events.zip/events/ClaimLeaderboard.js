const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const config = require('../config.js');

const claimsFilePath = path.join(__dirname, '../../claimsTicket.json');
const channelId2222 = config.ClaimsLeaderboardChannel;
const messageIdFile = path.join(__dirname, '../../ClaimsLeaderboardMessageId.txt');

function readClaims() {
    if (fs.existsSync(claimsFilePath)) {
        const data = fs.readFileSync(claimsFilePath, 'utf8');
        return JSON.parse(data);
    }
    return {};
}

async function updateEmbed(client) {
    const claims = readClaims();

    const sortedClaims = Object.entries(claims)
        .sort(([, a], [, b]) => b.amount - a.amount)
        .slice(0, 10);

    let description = '\n';
    sortedClaims.forEach(([userId, { amount }], index) => {
        let rank;
        switch (index) {
            case 0: rank = '🥇'; break;
            case 1: rank = '🥈'; break;
            case 2: rank = '🥉'; break;
            case 3: rank = '4️⃣'; break;
            case 4: rank = '5️⃣'; break;
            case 5: rank = '6️⃣'; break;
            case 6: rank = '7️⃣'; break;
            case 7: rank = '8️⃣'; break;
            case 8: rank = '9️⃣'; break;
            case 9: rank = '🔟'; break;
            default: rank = `${index + 1}`; break;
        }
        description += `\`(${rank})\` <@${userId}> - \`${amount}\` \n`;
    });

    const embed = new EmbedBuilder()
        .setColor(config.ServerColor)
        .setAuthor({ name: `${config.ServerName} | Leaderboard Claims`, iconURL: config.ServerIcon })
        .setDescription(description)
        .setThumbnail(config.ServerIcon)
        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
        .setTimestamp();

    try {
        const channel = await client.channels.fetch(channelId2222);
        let messageId = null;

        if (fs.existsSync(messageIdFile)) {
            messageId = fs.readFileSync(messageIdFile, 'utf8').trim();
        }

        if (channel) {
            if (messageId) {
                const message = await channel.messages.fetch(messageId);
                if (message) {
                    await message.edit({ embeds: [embed] });
                } else {
                    const newMessage = await channel.send({ embeds: [embed] });
                    fs.writeFileSync(messageIdFile, newMessage.id);
                }
            } else {
                const newMessage = await channel.send({ embeds: [embed] });
                fs.writeFileSync(messageIdFile, newMessage.id);
            }
        }
    } catch (error) {
    }
}

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        if (!config.ClaimsTicket) {
            return;
        }

        setInterval(() => updateEmbed(client), 20000);
    },
};