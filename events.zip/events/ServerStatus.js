const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ActivityType } = require('discord.js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const serverIp = `${config.FivemAddressIP}:${config.FivemPort}`;
const channelId = config.ServerStatusChannelId;
const messageIdFile = path.join(__dirname, '../../ServerStatusMessageId.txt');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        if (!config.ServerStatusFivem) {
            return;
        }

        updateServerStatus(client);
        setInterval(() => updateServerStatus(client), 20000);
    }
};

async function updateServerStatus(client) {
    if (!config.PlayerList) {
        return;
    }

    const channel = await client.channels.fetch(channelId);
    const guild = client.guilds.cache.get(config.GuildId);

    let messageId = null;
    if (fs.existsSync(messageIdFile)) {
        messageId = fs.readFileSync(messageIdFile, 'utf8').trim();
    }

    try {
        const response = await axios.get(`http://${serverIp}/players.json`);
        const response2 = await axios.get(`http://${serverIp}/info.json`);
        const players = response.data;
        const maxPlayers = response2.data.vars ? response2.data.vars.sv_maxClients : 'Unknown';

        const playerCount = players.length;

        const embedStatus = new EmbedBuilder()
            .setColor('#2aee3a')
            .setAuthor({ name: `${config.ServerName} | Server Status`, iconURL: config.ServerIcon })
            .addFields(
                { name: `Status`, value: `\`🟢 Online\``, inline: true },
                { name: `Players`, value: `\`🎮 ${playerCount}/${maxPlayers}\``, inline: true },
            )
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp()
            .setThumbnail(config.ServerIcon);

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('label111')
                .setLabel(`Server Is Online`)
                .setDisabled(true)
                .setStyle(ButtonStyle.Success)
            );

        if (!messageId) {
            const newMessage = await channel.send({ embeds: [embedStatus], components: [button] });
            fs.writeFileSync(messageIdFile, newMessage.id);
        } else {
                const message = await channel.messages.fetch(messageId);
                await message.edit({ embeds: [embedStatus], components: [button] });
        }

    } catch (error) {
        const embedOfflineStatus = new EmbedBuilder()
            .setColor('#ec1515')
            .setAuthor({ name: `${config.ServerName} | Server Status`, iconURL: config.ServerIcon })
            .addFields(
                { name: `Status`, value: `\`🔴 Offline\``, inline: true },
                { name: `Players`, value: `\`🎮 Offline\``, inline: true },
            )
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp()
            .setThumbnail(config.ServerIcon);

        const buttonOffline = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('label111')
                .setLabel(`Server Is Offline`)
                .setDisabled(true)
                .setStyle(ButtonStyle.Danger)
            );

        if (!messageId) {
            const newMessage = await channel.send({ embeds: [embedOfflineStatus], components: [buttonOffline] });
            fs.writeFileSync(messageIdFile, newMessage.id);
        } else {
                const message = await channel.messages.fetch(messageId);
                await message.edit({ embeds: [embedOfflineStatus], components: [buttonOffline] });
        }
    }
}