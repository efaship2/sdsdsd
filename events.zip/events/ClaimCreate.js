const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = './claimsTicket.json';
const config = require('../config.js');

if (!fs.existsSync(path)) {
    fs.writeFileSync(path, JSON.stringify({}));
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'button:claimticket11') {
        if (
            !interaction.member.roles.cache.some(
                role => role.id === `${config.StaffRoleId}` || role.id === `${config.ManagementRoleID}`
            )
        ) {
            return await interaction.reply({
                content: `**You Do Not Have The Required Permissions To Use This Button.**`,
                ephemeral: true
            });
        }
        
            const userId = interaction.user.id;
            const username = interaction.user.username;

            let claimsData = JSON.parse(fs.readFileSync(path));

            if (!claimsData[userId]) {
                claimsData[userId] = { amount: 0 };
            }

            claimsData[userId].amount += 1;

            fs.writeFileSync(path, JSON.stringify(claimsData, null, 2));

            const memberoption1 = new ButtonBuilder()
            .setCustomId('button:ticket:memberoption')
            .setLabel('Member Menu')
            .setStyle(ButtonStyle.Primary);

            const staffOption1 = new ButtonBuilder()
                .setCustomId('button:staff-option')
                .setLabel('Staff Menu')
                .setStyle(ButtonStyle.Primary);

            const updatedButton = new ButtonBuilder()
                .setCustomId('button:claimticket11')
                .setLabel(`Claimed: ${username}`)
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true);

            const row = new ActionRowBuilder()
                .addComponents(memberoption1, staffOption1, updatedButton);

            await interaction.update({
                components: [row]
            });

            await interaction.followUp({
                content: `\`✍\` ${interaction.user} **Claimed The Ticket.**`,
                ephemeral: false
            });

            const embedClaimTicketTicket = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setTitle('Ticket Claimed')
            .addFields(
                { name: 'Ticket Claimed By', value: `${interaction.user}`, inline: true },
                { name: `Ticket Claimed At`, value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true },
            )
            .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp();
    
            const logChannel = await client.channels.fetch(config.ChannelTicketLogsID);
            await logChannel.send({
                embeds: [embedClaimTicketTicket],
            });

        }
    }
};