const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.js');

const messageCache2 = new Map();

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const choices = ['✊', '🗒️', '✂️'];
        if (!choices.includes(interaction.customId)) return;

        const userChoice = interaction.customId;
        const botChoice = choices[Math.floor(Math.random() * choices.length)];
        let result;

        const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setTitle('תוצאות משחק | אבן נייר ומספריים')
            .setDescription(
                `**__הבחירה של הבוט:__** \n ${botChoice} \n\n` +
                `**__הבחירה שלך:__** \n ${userChoice}`
            );

        if (userChoice === botChoice) {
            result = `**תיקו! נסה שוב**`;
        } else if (
            (userChoice === '✊' && botChoice === '✂️') ||
            (userChoice === '🗒️' && botChoice === '✊') ||
            (userChoice === '✂️' && botChoice === '🗒️')
        ) {
            result = `**ניצחת! כל הכבוד**`;
        } else {
            result = `**הפסדת! לא נורא**`;
        }

        const disabledButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('🗒️')
                    .setEmoji('🗒️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            )
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('✊')
                    .setEmoji('✊')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true)
            )
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('✂️')
                    .setEmoji('✂️')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
            );

        await interaction.message.edit({ components: [disabledButtons] });
        await interaction.reply({ content: `${interaction.user}\n${result}`, embeds: [embed] });
    },
};
