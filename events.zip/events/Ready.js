const fs = require('fs');
const path = require('path');
const { ActivityType, EmbedBuilder } = require('discord.js');
const better = require("better-chalk");

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {

        const commandCount = client.commands.size;
        const commandDirectories = ['../commands/Fivem', '../commands/Invites', '../commands/Admin', '../commands/Community', '../commands/Setup', '../commands/Giveaway', '../commands/Tickets', '../commands/Xp'];
        let totalCommands = 0;

        commandDirectories.forEach(dir => {
            const commandPath = path.join(__dirname, dir);
            const commandFiles = fs.readdirSync(commandPath).filter(file => file.endsWith('.js'));
            totalCommands += commandFiles.length;
        });

        console.log(better.hex("#1aca35",true)+(`Loaded ${commandCount} Commands, ${totalCommands} In File.`));

        console.log(better.hex("#0000FF",true)+(`Logged is as ${client.user.username}`));

        async function pickPresence() {
            const option = Math.floor(Math.random() * statusArray.length);

            try {
                await client.user.setPresence({
                    activities: [
                        {
                            name: statusArray[option].content,
                            type: statusArray[option].type,
                        },
                    ],
                    status: statusArray[option].status
                });
            } catch (error) {
                console.error(error);
            }
        }
    },
};