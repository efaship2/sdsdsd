const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const invitesPath = path.join(__dirname, '../../invites.json');
const inviteCountPath = path.join(__dirname, '../../inviteCount.json');
const vanityPath = path.join(__dirname, '../../vanityUsers.json');

function loadFile(filePath, defaultValue = {}) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultValue));
    }
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function saveFile(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'guildMemberAdd',
    async execute(member) {
        const guild = member.guild;
        const invites = loadFile(invitesPath);
        const inviteCounts = loadFile(inviteCountPath);
        const vanityUsers = loadFile(vanityPath);

        const currentInvites = await guild.invites.fetch().catch(console.error);
        const vanityCode = guild.vanityURLCode;

        let usedInvite = null;

        if (currentInvites) {
            for (const invite of currentInvites.values()) {
                const savedInvite = invites[invite.code];
                if (savedInvite && savedInvite.uses < invite.uses) {
                    usedInvite = invite;
                    break;
                }
            }
        }

        if (usedInvite) {
            currentInvites.forEach(invite => {
                if (!invites[invite.code]) {
                    invites[invite.code] = { creator: invite.inviter.id, uses: invite.uses };
                } else {
                    invites[invite.code].uses = invite.uses;
                }
            });
            saveFile(invitesPath, invites);

            const inviterId = usedInvite.inviter.id;
            if (!inviteCounts[inviterId]) {
                inviteCounts[inviterId] = { joins: 0, lefts: 0 };
            }
            inviteCounts[inviterId].joins += 1;
            saveFile(inviteCountPath, inviteCounts);

            const inviteChannel = guild.channels.cache.get(config.InvitesChannel);
            if (inviteChannel) {
                inviteChannel.send(
                    `\`👋🏻\` **| ${member.user} has been invited by <@${inviterId}> and now has (\`${inviteCounts[inviterId].joins}\` Joins, \`${inviteCounts[inviterId].lefts}\` Lefts)**`
                ).catch(console.error);
            }
        } else if (vanityCode) {
            vanityUsers[member.id] = {
                joinedAt: new Date().toISOString(),
                vanityCode: vanityCode,
            };
            saveFile(vanityPath, vanityUsers);

            const inviteChannel = guild.channels.cache.get(config.InvitesChannel);
            if (inviteChannel) {
                inviteChannel.send(
                    `\`👋🏻\` **| ${member.user} Joined using the vanity invite.**`
                ).catch(console.error);
            }
        } else {
            const inviteChannel = guild.channels.cache.get(config.InvitesChannel);
            if (inviteChannel) {
                inviteChannel.send(
                    `\`❓\` **| I can not figure out how ${member.user} joined.**`
                ).catch(console.error);
            }
        }
    },
};