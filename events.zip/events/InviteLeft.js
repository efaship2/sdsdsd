const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const inviteCountPath = path.join(__dirname, '../../inviteCount.json');
const vanityPath = path.join(__dirname, '../../vanityUsers.json');

function loadFile(filePath, defaultValue = {}) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultValue));
    }
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function saveFile(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'guildMemberRemove',
    async execute(member) {
        const inviteCounts = loadFile(inviteCountPath);
        const vanityUsers = loadFile(vanityPath);

        if (vanityUsers[member.id]) {
            delete vanityUsers[member.id];
            saveFile(vanityPath, vanityUsers);

            const leaveChannel = member.guild.channels.cache.get(config.InvitesChannel);
            if (leaveChannel) {
                leaveChannel.send(
                    `\`❌\` **| ${member.user} Left, They joined using the vanity invite.**`
                ).catch(console.error);
            }
            return;
        }

        const inviterId = Object.keys(inviteCounts).find(id => {
            const counts = inviteCounts[id];
            return counts.joins > 0;
        });

        if (inviterId) {
            if (!inviteCounts[inviterId]) {
                inviteCounts[inviterId] = { joins: 0, lefts: 0 };
            }
            inviteCounts[inviterId].joins -= 1;
            inviteCounts[inviterId].lefts += 1;
            saveFile(inviteCountPath, inviteCounts);

            const leaveChannel = member.guild.channels.cache.get(config.InvitesChannel);
            if (leaveChannel) {
                leaveChannel.send(
                    `\`❌\` **| ${member.user} Left, They were invited by <@${inviterId}> and has now (\`${inviteCounts[inviterId].joins}\` Joins, \`${inviteCounts[inviterId].lefts}\` Lefts)**`
                ).catch(console.error);
            }
        } else {
            const leaveChannel = member.guild.channels.cache.get(config.InvitesChannel);
            if (leaveChannel) {
                leaveChannel.send(
                    `\`❓\` **| ${member.user} Left, I can not figure out how they joined.**`
                ).catch(console.error);
            }
        }
    },
};