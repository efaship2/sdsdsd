const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const xpChannelFilePath = path.join(__dirname, '../../xpChannel.json');

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        if (!config.Xp) {
            return;
        }
        if (message.author.bot) return;

        const xpFile = './xpLevels.json';
        let xpData = {};

        try {
            xpData = JSON.parse(fs.readFileSync(xpFile, 'utf8'));
        } catch (error) {
            console.error('Failed to read xpLevels.json. Creating a new file.');
        }

        let xpChannelData;
        try {
          xpChannelData = JSON.parse(fs.readFileSync(xpChannelFilePath, 'utf8'));
        } catch (error) {
          return;
        }
  
        const idchannel22 = xpChannelData.xpChannel;

        const userId = message.author.id;

        if (!xpData[userId]) {
            xpData[userId] = { xp: 0, level: 1 };

            fs.writeFileSync(xpFile, JSON.stringify(xpData, null, 2), 'utf8');

            const levelUpChannelId = idchannel22;
            const levelUpChannel = message.guild.channels.cache.get(levelUpChannelId);

            if (levelUpChannel) {
                levelUpChannel.send(
                    `\`🎉\` ${message.author} Has Leveled Up To **Level 1!**`
                );
            }
        }

        const { xp, level } = xpData[userId];

        const xpGain = Math.floor(Math.random() * 10) + 1;
        xpData[userId].xp += xpGain;

        const nextLevelXp = (xpData[userId].level + 1) * 100;

        if (xpData[userId].xp >= nextLevelXp) {
            xpData[userId].level += 1;

            const levelUpChannelId = idchannel22;
            const levelUpChannel = message.guild.channels.cache.get(levelUpChannelId);

            if (levelUpChannel) {
                levelUpChannel.send(
                    `\`🎉\` ${message.author} Has Leveled Up To **Level ${xpData[userId].level}!**`
                );
            }
        }

        fs.writeFileSync(xpFile, JSON.stringify(xpData, null, 2), 'utf8');
    },
};
