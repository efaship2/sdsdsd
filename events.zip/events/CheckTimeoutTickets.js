const fs = require('fs');
const path = require('path');

const timeoutsFilePath = path.join(__dirname, '../../timeoutsTickets.json');

setInterval(() => {
    if (fs.existsSync(timeoutsFilePath)) {
        const timeouts = JSON.parse(fs.readFileSync(timeoutsFilePath));
        const now = Date.now();

        for (const userId in timeouts) {
            if (timeouts[userId] <= now) {
                delete timeouts[userId];
            }
        }

        fs.writeFileSync(timeoutsFilePath, JSON.stringify(timeouts));
    }
}, 20000);
