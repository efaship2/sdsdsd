const { EmbedBuilder, Interaction } = require("discord.js");
const config = require('../config.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId === 'modal:option1') {
            const userId = interaction.fields.getTextInputValue('user-id');
            try {
                const member = await interaction.guild.members.fetch(userId);
                await interaction.channel.permissionOverwrites.create(userId, { ViewChannel: true, SendMessages: true });
                await interaction.reply({ content: `<@${userId}> **Added To The Ticket By** ${interaction.user}`, ephemeral: false });

                const embedAddUserTicket = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setTitle('Add User To Ticket')
                .addFields(
                    { name: 'User Added By', value: `${interaction.user}`, inline: true },
                    { name: 'User Added', value: `<@${userId}>`, inline: true },
                    { name: 'User Added At', value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();
        
                const logChannel = await client.channels.fetch(config.ChannelTicketLogsID);
                await logChannel.send({
                    embeds: [embedAddUserTicket],
                });

            } catch (error) {
                console.error('Error adding user:', error);
                await interaction.reply({ content: `Failed To Add User To The Ticket.`, ephemeral: true });
            }
        } else if (interaction.customId === 'modal:option2') {
            const userId = interaction.fields.getTextInputValue('user-id');
            try {
                await interaction.channel.permissionOverwrites.delete(userId);
                await interaction.reply({ content: `<@${userId}> **Removed From The Ticket By** ${interaction.user}`, ephemeral: false });

                const embedAddUserTicket = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setTitle('Remove User From Ticket')
                .addFields(
                    { name: 'User Removed By', value: `${interaction.user}`, inline: true },
                    { name: 'User Removed', value: `<@${userId}>`, inline: true },
                    { name: 'User Removed At', value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();
        
                const logChannel = await client.channels.fetch(config.ChannelTicketLogsID);
                await logChannel.send({
                    embeds: [embedAddUserTicket],
                });

            } catch (error) {
                console.error('Error removing user:', error);
                await interaction.reply({ content: `Failed to remove user from the ticket.`, ephemeral: true });
            }
        } else if (interaction.customId === 'modal:option5') {
            const newName = interaction.fields.getTextInputValue('new-name');
            try {
                if (newName && newName.length <= 100) {
                    await interaction.channel.setName(`${newName}`);
                    await interaction.reply({ content: `**Ticket Has Been Renamed By ${interaction.user} To | \`${newName}\`**` });

                    const embedAddUserTicket = new EmbedBuilder()
                    .setColor(config.ServerColor)
                    .setTitle('Rename To Ticket')
                    .addFields(
                        { name: 'Ticket Rename By', value: `${interaction.user}`, inline: true },
                        { name: 'New Name', value: `${newName}`, inline: true },
                        { name: 'Ticket Rename At', value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true },
                    )
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setTimestamp();
            
                    const logChannel = await client.channels.fetch(config.ChannelTicketLogsID);
                    await logChannel.send({
                        embeds: [embedAddUserTicket],
                    });

                } else {
                    await interaction.reply({ content: `The new name is invalid. Please ensure it is not empty and under 100 characters.`, ephemeral: true });
                }
            } catch (error) {
                console.error('Error renaming ticket:', error);
                await interaction.reply({ content: `Failed to rename the ticket.`, ephemeral: true });
            }
        }
    }
};