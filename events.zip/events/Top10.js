const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.js');

const channelId22222 = config.Top10ChannelId;
const messageIdFile = path.join(__dirname, '../../Top10MessageId.txt');

function formatTime(minutes) {
    if (!config.Top10) {
        return;
    }
    const days = Math.floor(minutes / 1440);
    const hours = Math.floor((minutes % 1440) / 60);
    const mins = minutes % 60;
    return `${days} Days, ${hours} Hours, ${mins} Minutes`;
}

async function updateLeaderboard(client) {
    if (!config.Top10) {
        return;
    }
    const data = JSON.parse(fs.readFileSync('./playtime.json'));
    const leaderboard = Object.entries(data)
        .map(([userId, minutes]) => {
            return { userId, time: formatTime(minutes) };
        })
        .sort((a, b) => b.time.localeCompare(a.time))
        .slice(0, 10);

    if (leaderboard.length === 0) {
        return;
    }

    const description = leaderboard.map((entry, index) => `\`${index + 1}.\` <@${entry.userId}> \`${entry.time}\``).join('\n');
    
    if (!description) {
        return;
    }

    const embed = new EmbedBuilder()
        .setTitle(`\`🏆\` ${config.ServerName} | Top 10`)
        .setDescription(description)
        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
        .setThumbnail(config.ServerIcon)
        .setTimestamp()
        .setColor(config.ServerColor);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('check_playtime')
                .setLabel('Check Your Playtime')
                .setEmoji(`⭐`)
                .setStyle(ButtonStyle.Primary)
        );

    const channel = client.channels.cache.get(channelId22222);
    if (channel) {
        let messageId = null;
        if (fs.existsSync(messageIdFile)) {
            messageId = fs.readFileSync(messageIdFile, 'utf8').trim();
        }

        if (!messageId) {
            const newMessage = await channel.send({ embeds: [embed], components: [row] });
            fs.writeFileSync(messageIdFile, newMessage.id);
        } else {
            try {
                const message = await channel.messages.fetch(messageId);
                await message.edit({ embeds: [embed], components: [row] });
            } catch (err) {
                if (err.code === 10008) {
                    const newMessage = await channel.send({ embeds: [embed], components: [row] });
                    fs.writeFileSync(messageIdFile, newMessage.id);
                }
            }
        }
    }
}

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        if (!config.Top10) {
            return;
        }
        updateLeaderboard(client);
        setInterval(() => updateLeaderboard(client), 20000);

        client.on('interactionCreate', async interaction => {
            if (!interaction.isButton()) return;

            if (interaction.customId === 'check_playtime') {
                const userId = interaction.user.id;
                const data = JSON.parse(fs.readFileSync('./playtime.json'));

                if (!data[userId]) {
                    await interaction.reply({ content: `**Your Playtime Is:**\n\`0 Days, 0 Hours, 0 Minutes\``, ephemeral: true });
                } else {
                    const time = formatTime(data[userId]);
                    await interaction.reply({ content: `**Your Playtime Is:**\n\`${time}\``, ephemeral: true });
                }
            }
        });
    }
};