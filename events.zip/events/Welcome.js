const { ButtonStyle, ButtonBuilder, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const welcomeChannelFilePath = path.join(__dirname, '../../welcomeChannel.json');

module.exports = {
    name: 'guildMemberAdd',
    execute(member) {
        const config = require('../config.js');

        if (!config.Welcome) {
            return;
        }

        let welcomeChannelData;
        try {
            welcomeChannelData = JSON.parse(fs.readFileSync(welcomeChannelFilePath, 'utf8'));
        } catch (error) {
            return;
        }

        const welcomeChannel = member.guild.channels.cache.get(`${welcomeChannelData.welcomeChannel}`);
        const membercount22 = member.guild.memberCount;

        const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `Welcome To ${config.ServerName}`, iconURL: config.ServerIcon })
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setDescription(`Hey ${member}, Welcome To \`${config.ServerName}\`!\nWe Are Now **${membercount22}** Members!`)
            .setTimestamp();

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('memberssssss')
                    .setLabel(`${membercount22} Members`)
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('<:joinmember:1300768870214271048>')
                    .setDisabled(true)
            );

        welcomeChannel.send({ content: `||${member}||`, embeds: [embed], components: [button] });
    },
};