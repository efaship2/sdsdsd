const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const axios = require('axios');
const config = require('../config.js');

const serverIp = `${config.FivemAddressIP}:${config.FivemPort}`;
const channelId = config.StaffOnlineChannelId;
const messageIdFile = path.join(__dirname, '../../StaffOnlineMessageId.txt');
const requiredRoleId = config.StaffRoleId;

async function updatePlayerList(client) {
    const channel = await client.channels.fetch(channelId);
    const guild = client.guilds.cache.get(config.GuildId);

    let messageId = null;
    if (fs.existsSync(messageIdFile)) {
        messageId = fs.readFileSync(messageIdFile, 'utf8').trim();
    }

    try {
        const response = await axios.get(`http://${serverIp}/players.json`);
        const players = response.data;

        const playerLines = [];
        for (const player of players) {
            const discordId = player.identifiers.find(id => id.startsWith('discord:'));
            if (discordId) {
                const discordTag = discordId.replace('discord:', '');
                const member = await guild.members.fetch(discordTag).catch(() => null);

                if (member && member.roles.cache.has(requiredRoleId)) {
                    playerLines.push(`**[ID: ${player.id || 'Unknown'}]** ${player.name ? `\`${player.name}\`` : 'Unknown'} <@${discordTag}>`);
                }
            }
        }

        const playerListDescription = playerLines.join('\n') || 'None';

        const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${config.ServerName} | Staff Online`, iconURL: config.ServerIcon })
            .setDescription(playerListDescription)
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp();

        if (messageId) {
            const message = await channel.messages.fetch(messageId).catch(() => null);
            if (message) {
                await message.edit({ embeds: [embed] });
            } else {
                const newMessage = await channel.send({ embeds: [embed] });
                fs.writeFileSync(messageIdFile, newMessage.id);
            }
        } else {
            const newMessage = await channel.send({ embeds: [embed] });
            fs.writeFileSync(messageIdFile, newMessage.id);
        }
    } catch (error) {
        const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${config.ServerName} | Staff Online`, iconURL: config.ServerIcon })
            .setDescription('Server Is Offline')
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp();

        if (messageId) {
            const message = await channel.messages.fetch(messageId).catch(() => null);
            if (message) {
                await message.edit({ embeds: [embed] });
            } else {
                const newMessage = await channel.send({ embeds: [embed] });
                fs.writeFileSync(messageIdFile, newMessage.id);
            }
        } else {
            const newMessage = await channel.send({ embeds: [embed] });
            fs.writeFileSync(messageIdFile, newMessage.id);
        }
    }
}

module.exports = (client) => {
    updatePlayerList(client);
    setInterval(() => updatePlayerList(client), 20000);
};
