const { Events, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder, EmbedBuilder } = require('discord.js');
const { createTranscript } = require('discord-html-transcripts');
const config = require('../config.js')

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        if (!config.TicketLogs) {
            return;
        }
        if (interaction.isButton()) {
            const ticketChannel = interaction.channel;

            switch (interaction.customId) {

                case 'button:option3':
                    try {
                        const ticketOwnerId = interaction.user.id 

                        if (!ticketOwnerId) {
                            await interaction.reply({ content: 'Unable to determine the ticket owner. Please ensure the ticket channel topic is set correctly.', ephemeral: true });
                            return;
                        }

                        const ticketOwner = await client.users.fetch(ticketOwnerId);
                        const logs = interaction.guild.channels.cache.get(config.ChannelTicketLogsID);
                        const attachment = await createTranscript(ticketChannel, {
                            limit: -1,
                            returnBuffer: false,
                            fileName: `${ticketChannel.name}.html`
                        });

                        let summary = {};
                        ticketChannel.messages.cache.forEach(message => {
                            if (summary.hasOwnProperty(message.author.id))
                                summary[message.author.id].number++;
                            else
                                summary[message.author.id] = { number: 0, user: message.author };
                        });

                        let amount = "";
                        for (const user in summary) {
                            amount += `\`${summary[user].number + 1}\` -  ${summary[user].user.tag}\n(${summary[user].user.id})\n`;
                        }

                        const key = Object.keys(summary).sort((a, b) => summary[b].number - summary[a].number)[0];
                        const logEmbed = new EmbedBuilder()
                            .setColor(config.ServerColor)
                            .setTitle(`Save Transcripts`)
                            .addFields({ name: `Ticket Saved By`, value: `${interaction.user}`, inline: true })
                            .addFields({ name: `Ticket Opened At`, value: `<t:${parseInt(ticketChannel.createdTimestamp / 1000)}>`, inline: true })
                            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                            .setTimestamp();

                        await logs.send({ embeds: [logEmbed], files: [attachment] });
                        await interaction.reply({ content: '**Ticket Export Completed And Logged.**', ephemeral: true });
                    } catch (error) {
                        console.error('Error exporting ticket transcripts:', error);
                        await interaction.reply({ content: 'There was an error exporting the ticket transcripts. Please try again later.', ephemeral: true });
                    }
                    break;

case 'button:ticket-close':
    try {
        if (!config.TicketLogs) {
            return;
        }
        const ticketOwnerId = interaction.user.id;
        const ticketOwner = await client.users.fetch(ticketOwnerId);
        const logs = interaction.guild.channels.cache.get(config.ChannelTicketLogsID);
        const attachment = await createTranscript(ticketChannel, {
            limit: -1,
            returnBuffer: false,
            fileName: `${ticketChannel.name}.html`
        });

        let summary = {};
        ticketChannel.messages.cache.forEach(message => {
            if (summary.hasOwnProperty(message.author.id))
                summary[message.author.id].number++;
            else
                summary[message.author.id] = { number: 0, user: message.author };
        });

        let amount = "";
        for (const user in summary) {
            amount += `\`${summary[user].number + 1}\` -  ${summary[user].user.tag}\n(${summary[user].user.id})\n`;
        }

        const key = Object.keys(summary).sort((a, b) => summary[b].number - summary[a].number)[0];
        const logEmbed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setTitle(`Ticket Closed`)
            .addFields({ name: `Ticket Closed By`, value: `${interaction.user}`, inline: true })
            .addFields({ name: `Ticket Closed At`, value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true })
            .addFields({ name: `Ticket Opened At`, value: `<t:${parseInt(ticketChannel.createdTimestamp / 1000)}>`, inline: true })
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setTimestamp();

        await logs.send({ embeds: [logEmbed], files: [attachment] });
    } catch (error) {
    }

}
}
},
};
