const fs = require('fs');
const http = require('http');
const config = require('../config.js');

const playtimeFile = './playtime.json';

if (!fs.existsSync(playtimeFile)) {
    if (!config.PlayTime) {
        return;
    }
    fs.writeFileSync(playtimeFile, JSON.stringify({}, null, 2), 'utf8');
}

let playtimeData = JSON.parse(fs.readFileSync(playtimeFile, 'utf8'));

const FIVEM_SERVER_IP = config.FivemAddressIP;
const FIVEM_SERVER_PORT = config.FivemPort;

function updatePlaytime(discordId) {
    if (!config.PlayTime) {
        return;
    }
    if (!playtimeData[discordId]) {
        playtimeData[discordId] = 0;
    }
    playtimeData[discordId] += 1;
}

function savePlaytime() {
    if (!config.PlayTime) {
        return;
    }
    fs.writeFileSync(playtimeFile, JSON.stringify(playtimeData, null, 2), 'utf8');
}

function getPlayers(callback) {
    if (!config.PlayTime) {
        return;
    }
    const options = {
        hostname: FIVEM_SERVER_IP,
        port: FIVEM_SERVER_PORT,
        path: '/players.json',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    };

    const req = http.request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            try {
                const players = JSON.parse(data);
                callback(null, players);
            } catch (error) {
                callback(error);
            }
        });
    });

    req.on('error', (error) => {
        callback(error);
    });

    req.end();
}

function trackPlaytime() {
    getPlayers((error, players) => {
        if (error) {
            return;
        }

        players.forEach((player) => {
            const discordId = player.identifiers.find(id => id.startsWith('discord:'));
            if (discordId) {
                updatePlaytime(discordId.split(':')[1]);
            }
        });

        savePlaytime();
    });
}

setInterval(trackPlaytime, 60 * 1000);
