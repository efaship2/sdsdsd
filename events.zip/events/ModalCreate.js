const { Interaction } = require("discord.js");

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isModalSubmit()) return;
        if(interaction.customId === 'modal') {
            
            const name = interaction.fields.getTextInputValue('name');
            if(!interaction.channel.name.includes('ticket-')) return interaction.reply({ content: 'This channel is not the ticket.', ephemeral: true})
            if(interaction.channel.name.includes('ticket-')) {
                await interaction.channel.setName(`ticket-${name}`)
                return await interaction.reply({ content: 'Rename Ticket.', ephemeral: true})
             }
        }
    }
}