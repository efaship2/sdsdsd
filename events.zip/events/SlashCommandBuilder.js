const { Events, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const config = require('../config.js');

const logsConfig = JSON.parse(fs.readFileSync('./logsChannel.json', 'utf8'));

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isCommand()) return;

        if (!config.MainLogs) {
            return;
        }

        const logChannelId = logsConfig.logsChannel;
        const logChannel = interaction.guild.channels.cache.get(logChannelId);

        if (!logChannel) {
            console.error(`Could not find log channel with ID: ${logChannelId}`);
            return;
        }

        const commandName = interaction.commandName;
        const user = interaction.user;
        const userId = interaction.user.id;
        const options = interaction.options.data;

        const optionsText = options.length > 0
            ? options.map(option => `${option.name}: ${option.value || 'This Command Has No Options'}`).join(', ')
            : 'This Command Has No Options';

        const logMessage = `**__User:__**\n${user} (${userId})\n\n**__Command:__**\n\`${commandName}\`\n\n__**Command Options:**__\n\`${optionsText}\``;

        const embed = new EmbedBuilder()
            .setColor('#e34646')
            .setAuthor({ name: 'Tzuri Commands Logs', iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setDescription(logMessage)
            .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp();

        logChannel.send({ embeds: [embed] });
    },
};