const fs = require('fs');
const path = require('path');
const { ChannelType, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.js');
const filePath = path.join(__dirname, '../../ticketCategorys.json');
const statsFilePath = path.join(__dirname, '../../ticketStats.json');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isSelectMenu()) return;
        if (interaction.customId === 'ticket_creation') {
            let ticketCategories = JSON.parse(fs.readFileSync(filePath, 'utf8'));

            const categoryMapping = ticketCategories.categories.reduce((mapping, category, index) => {
                const categoryName = category.name;
                const categoryEmoji = category.emoji || '';
                const categoryDescription = category.description || '';
                mapping[`option${index + 1}`] = { name: categoryName, emoji: categoryEmoji, description: categoryDescription };
                return mapping;
            }, {});

            const selectedOption = interaction.values[0];
            const selectedCategory = categoryMapping[selectedOption];

            if (selectedCategory) {
                try {
                    const channel = await interaction.guild.channels.create({
                        name: `ticket-${interaction.user.tag}`,
                        type: ChannelType.GuildText,
                        parent: config.TicketCategorys,
                    });

                    await channel.permissionOverwrites.create(config.StaffRoleId, { ViewChannel: true, SendMessages: true, AttachFiles: true });
                    await channel.permissionOverwrites.create(interaction.user.id, { ViewChannel: true, SendMessages: true, AttachFiles: true });
                    await channel.permissionOverwrites.create(channel.guild.roles.everyone, { ViewChannel: false, SendMessages: false });

                    const categoryName = selectedCategory.name;
                    const categoryEmoji = selectedCategory.emoji;

                    const embedTickets = new EmbedBuilder()
                        .setColor(config.ServerColor)
                        .setAuthor({ name: `${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                        .setTitle(`Support Tickets`)
                        .setDescription(`
היי ${interaction.user},
אנא פרט את סיבת הפנייה. הצוות שלנו יעזור לך בהקדם האפשרי.

**נושא הפנייה - __${categoryName}__**
                            `)
                        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                        .setTimestamp()
                        .setThumbnail(config.ServerIcon);

                    const button = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                        .setCustomId('button:ticket:memberoption')
                        .setLabel('Member Menu')
                        .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId('button:staff-option')
                            .setLabel('Staff Menu')
                            .setStyle(ButtonStyle.Primary)
                    )

                    if (config.ClaimsTicket) {
                        button.addComponents(
                            new ButtonBuilder()
                                .setCustomId('button:claimticket11')
                                .setLabel('Claim')
                                .setStyle(ButtonStyle.Success)
                        );
                    }

                    const message = await channel.send({ content: `${interaction.user} | <@&${config.StaffRoleId}>`, embeds: [embedTickets], components: [button] });

                    await message.pin();
                
                    const embedOpened = new EmbedBuilder()
                        .setColor('#68c06f')
                        .setDescription(`> **Your Ticket Created |** <#${channel.id}>`);

                    const embedOpeningTicket = new EmbedBuilder()
                        .setColor(config.ServerColor)
                        .setTitle('Open Ticket')
                        .addFields(
                            { name: 'Ticket Open By', value: `${interaction.user}`, inline: true },
                            { name: 'Ticket Channel', value: `<#${channel.id}>`, inline: true },
                            { name: 'Ticket Open At', value: `<t:${parseInt(Date.now() / 1000)}>`, inline: true },
                        )
                        .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                        .setTimestamp();

                    const logChannel = await client.channels.fetch(config.ChannelTicketLogsID);
                    logChannel.send({ embeds: [embedOpeningTicket] });

                    let ticketStats = {};
                    if (fs.existsSync(statsFilePath)) {
                        ticketStats = JSON.parse(fs.readFileSync(statsFilePath, 'utf8'));
                    }

                    if (!ticketStats[interaction.user.id]) {
                        ticketStats[interaction.user.id] = { ticketOpening: 0, date: [] };
                    }

                    ticketStats[interaction.user.id].ticketOpening += 1;
                    ticketStats[interaction.user.id].date.push(new Date().toISOString());

                    fs.writeFileSync(statsFilePath, JSON.stringify(ticketStats, null, 2), 'utf8');

                    await interaction.update({ embeds: [embedOpened], components: [], ephemeral: true });
                } catch (error) {
                    console.error('Error creating ticket:', error);
                }
            }
        }
    }
};