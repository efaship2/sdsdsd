const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.js');

const cooldowns = new Map();

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'button:ticket:memberoption') {
            const messageContent = interaction.message.content;
        
            const memberTag = messageContent.match(/<@!?(\d+)>/);
            
            if (!memberTag) {
                return interaction.reply({ content: '**נמצא בעיה בכפתור זה, נא לפנות לצוות השרת.**', ephemeral: true });
            }
    
            const memberId = memberTag[1];

            const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setDescription(`**Hello ${interaction.user}, Welcome To The Member Ticket Menu.**`)

            const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('memberoption:requestclose')
                .setLabel('Request Close')
                .setStyle(ButtonStyle.Secondary)
            )
            .addComponents(
                new ButtonBuilder()
                .setCustomId('memberoption:calladmin')
                .setLabel('Call To Admin')
                .setStyle(ButtonStyle.Primary)
            )

            if (interaction.user.id === memberId) {
                return interaction.reply({ embeds: [embed], components: [button], ephemeral: true });
            } else {
                return interaction.reply({ content: '**You Are Not Ticket Owner.**', ephemeral: true });
            }
        }

        if (interaction.customId === 'memberoption:calladmin') {
            const currentTime = Date.now();
            const cooldownTime = 5 * 60 * 1000;
            const userId = interaction.user.id;

            if (cooldowns.has(userId)) {
                const lastUsed = cooldowns.get(userId);
                const timePassed = currentTime - lastUsed;

                if (timePassed < cooldownTime) {
                    const timeLeft = cooldownTime - timePassed;
                    const timeStamp = Math.floor((currentTime + timeLeft) / 1000);
                    const embed11 = new EmbedBuilder()
                    .setColor(config.ServerColor)
                    .setDescription(`> **You Have Cooldown <t:${timeStamp}:R>**`)
                    return interaction.reply({ 
                        embeds: [embed11],
                        ephemeral: true
                    });
                }
            }

            const embed4 = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setDescription(`${interaction.user} **Call To Admin**`)

            cooldowns.set(userId, currentTime);
            await interaction.deferUpdate();
            return interaction.channel.send({ content: `<@&${config.StaffRoleId}>`, embeds: [embed4] });
        }

        if (interaction.customId === 'memberoption:requestclose') {
            const currentTime = Date.now();
            const cooldownTime = 5 * 60 * 1000;
            const userId = interaction.user.id;

            if (cooldowns.has(userId)) {
                const lastUsed = cooldowns.get(userId);
                const timePassed = currentTime - lastUsed;

                if (timePassed < cooldownTime) {
                    const timeLeft = cooldownTime - timePassed;
                    const timeStamp = Math.floor((currentTime + timeLeft) / 1000);
                    const embed11 = new EmbedBuilder()
                    .setColor(config.ServerColor)
                    .setDescription(`> **You Have Cooldown <t:${timeStamp}:R>**`)
                    return interaction.reply({ 
                        embeds: [embed11],
                        ephemeral: true
                    });
                }
            }

            const embed5 = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setDescription(`${interaction.user} **Request Closed Ticket**`)

            cooldowns.set(userId, currentTime);
            await interaction.deferUpdate();
            return interaction.channel.send({ embeds: [embed5] });
        }
        },
};