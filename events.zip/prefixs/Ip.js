const { ButtonStyle, ButtonBuilder, ActionRowBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        if (message.content === `${config.PrefixsBot}ip`) {
            if (!config.IP) {
                return;
            }

            let ipData;
            try {
                const filePath = path.join(__dirname, '../../fivemIpAdress.json');
                const data = fs.readFileSync(filePath, 'utf8');
                ipData = JSON.parse(data);
            } catch (error) {
                console.error('Error reading the fivemIpAdress.json file:', error);
                return;
            }

            let serverStatus1 = '🔴';
            let serverStatus2 = 'Server Is Offline';
            try {
                const response = await axios.get(`http://${config.FivemAddressIP}:${config.FivemPort}/info.json`, {
                    timeout: 5000
                });

                const response2 = await axios.get(`http://${config.FivemAddressIP}:${config.FivemPort}/players.json`, {
                    timeout: 5000
                });

                if (response.status === 200 && response.data) {
                    const players = response2.data.length;
                    const maxPlayers = response.data.vars ? response.data.vars.sv_maxClients : 'Unknown';

                    serverStatus1 = '🟢';
                    serverStatus2 = `Online, ${players}/${maxPlayers}`;
                }
            } catch (error) {
            }

            const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({
                name: `${config.ServerName} | Server Status`,
                iconURL: message.guild.iconURL({ dynamic: true })
            })
            .setDescription(
                `${serverStatus1} **__Status:__ \`${serverStatus2}\`**\n` +
                `🐌 **__FiveM:__ \`${ipData.FivemIpAdress}\`**\n` +
                `🎙️ **__Mumble:__ \`Mumble, VOICE CHAT ON\`**\n\n`
            )
            .setFooter({
                text: `Developer: tzuri1`,
                iconURL: message.guild.iconURL({ dynamic: true })
            })
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setTimestamp();

            message.reply({ embeds: [embed] });
        }
    });
};
