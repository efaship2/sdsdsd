const { ButtonStyle, ButtonBuilder, ActionRowBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, MessageManager, Embed, Collection, PermissionsBitField, Timeouts } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
const config = require('../config.js');

const allowedChannels = config.AntiLinkChannelWhitelist || [];
const allowedCategories = config.AntiLinkCategoryWhitelist || [];

module.exports = (client) => {
    const handleLinkDetection = async (message) => {
        if (!config.AntiLink1) return;

        if (allowedChannels.includes(message.channel.id)) return;
        if (message.channel.parentId && allowedCategories.includes(message.channel.parentId)) return;

        if (message.content.includes('https://') || message.content.includes('www') || message.content.includes('.co.il') || message.content.includes('discord.gg')) {

            if (message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

            await message.delete();
            await message.member.timeout(300 * 1000, 'Posted a link in a restricted area.');

            const embed = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setDescription(`${message.member} | **You Can't Send Links In This Server.**`);

            const warningMessage = await message.channel.send({ embeds: [embed] });

        }
    };

    client.on('messageCreate', async (message) => {
        if (!config.AntiLink1) return;
        await handleLinkDetection(message);
    });

    client.on('messageUpdate', async (oldMessage, newMessage) => {
        if (!config.AntiLink1) return;
        if (!oldMessage.author.bot) {
            await handleLinkDetection(newMessage);
        }
    });
};
