const { ButtonStyle, ButtonBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, SelectMenuBuilder,  ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
    client.on('voiceStateUpdate', (oldState, newState) => {
        if (!config.Stats) {
            return;
        }
        const userId = oldState.member.id;
    
        if (!newState.channelId && oldState.channelId) {
            const connectedAt = oldState.member.voice.connectedAt;
            if (connectedAt) {
                const sessionDuration = Math.floor((Date.now() - connectedAt.getTime()) / 1000);
                require('../commands/Community/stats.js').updateVoiceTime(userId, sessionDuration);
            }
        }
    
        if (newState.channelId && !oldState.channelId) {
            newState.member.voice.connectedAt = new Date();
        }
    });
    
    
    client.on('messageCreate', (message) => {
        if (!config.Stats) {
            return;
        }
        if (message.author.bot) return;
    
        require('../commands/Community/stats.js').countMessage(message);
    });
}