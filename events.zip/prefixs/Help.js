const { ChannelType, UserSelectMenuBuilder, SlashCommandBuilder, StringSelectMenuOptionBuilder, StringSelectMenuBuilder, InteractionType, ButtonStyle, ButtonBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, SelectMenuBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType, AuditLogEvent, ComponentType } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;

    const args = message.content.split(' ').slice(1);
    const reason = args.join(' ') || '`אין סיבה`';

    if (message.content.toLowerCase().startsWith(`${config.PrefixsBot}h`)) {
        if (!config.Helps) {
            return;
        }
        const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${config.ServerName} | Help`, iconURL: config.ServerIcon })
            .setThumbnail(message.author.displayAvatarURL())
            .setFooter({ text: `Developer: CodyDEV`, iconURL: config.ServerIcon })
            .setDescription(`**__סיבה:__** \n \`${reason}\` \n\n __**נמצא בוויס:**__ \n ${message.member.voice.channel ? `<#${message.member.voice.channel.id}>` : '`לא נמצא בוויס`'}`);

        const button = new ButtonBuilder()
            .setCustomId('help_button')
            .setLabel('Claim')
            .setStyle('Success');

        const row = new ActionRowBuilder().addComponents(button);

        await message.reply({ content: `<@&${config.StaffRoleId}>`, embeds: [embed], components: [row] });
    }
});

client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'help_button') {
        if (
            !interaction.member.roles.cache.some(
                role => role.id === `${config.StaffRoleId}` || role.id === `${config.ManagementRoleID}`
            )
        ) {
            return await interaction.reply({
                content: `**You Do Not Have The Required Permissions To Use This Button.**`,
                ephemeral: true
            });
        }

        const member = interaction.member;

        const updatedButton = new ButtonBuilder()
            .setCustomId('help_button')
            .setLabel(`Claimed By: ${member.user.username}`)
            .setStyle('Secondary')
            .setDisabled(true);

        const updatedRow = new ActionRowBuilder().addComponents(updatedButton);

        await interaction.update({
            components: [updatedRow],
        });

        interaction.followUp({ content: `**You Claimed The Help.**`, ephemeral: true });
    }
});
};