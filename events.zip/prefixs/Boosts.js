const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.js');
const client = new Client({ 
    intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] 
});

const boostChannelFilePath = path.join(__dirname, '../../boostChannel.json');

module.exports = (client) => {
  client.on('guildMemberUpdate', async (oldMember, newMember) => {
    if (!config.Boosts) {
      return;
    }

    if (!oldMember.premiumSince && newMember.premiumSince) {
      let avatarURL = newMember.user.displayAvatarURL({ format: 'webp', dynamic: true, size: 1024 });
      avatarURL = avatarURL.replace('.webp', '.png');
      let boostCount = newMember.guild.premiumSubscriptionCount;

      let boostChannelData;
      try {
        boostChannelData = JSON.parse(fs.readFileSync(boostChannelFilePath, 'utf8'));
      } catch (error) {
        return;
      }

      const idchannel = boostChannelData.boostChannel;

      let embed = new EmbedBuilder()
        .setColor('#ec1cff')
        .setDescription(`Thanks **${newMember.user.username}** for boosting! We are now at **${boostCount}** boosts!`)
        .setImage(`https://api.aggelos-007.xyz/boostcard?avatar=${avatarURL}&username=${newMember.user.username}`)
        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
        .setTimestamp();

      const boostChannel = client.channels.cache.get(idchannel);
      if (boostChannel) {
        boostChannel.send({ embeds: [embed] });
      } else {
      }
    }
  });
};