const { ChannelType, UserSelectMenuBuilder, SlashCommandBuilder, StringSelectMenuOptionBuilder, StringSelectMenuBuilder, InteractionType, ButtonStyle, ButtonBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, SelectMenuBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType, AuditLogEvent, ComponentType } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
    const prefix = config.PrefixsBot;

    client.on('messageCreate', async (message) => {
        if (!config.Verify2) {
            return;
        }
        if (!message.content.startsWith(prefix) || message.author.bot) return;
    
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();
    
        if (command === 'verify2') {
            if (!message.member.roles.cache.has(config.StaffRoleId)) {
                return message.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**` });
            }
    
            const embed = new EmbedBuilder()
                .setAuthor({ name: `${config.ServerName} - Verify System`, iconURL: config.ServerIcon })
                .setDescription('**Press The** \`Click Me\` **To Start The Verify.**')
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp()
                .setColor(config.ServerColor);
    
            const startButton = new ButtonBuilder()
                .setCustomId('start-verification')
                .setLabel('Click Me')
                .setStyle(ButtonStyle.Primary);
    
            const row = new ActionRowBuilder().addComponents(startButton);
    
            await message.channel.send({ embeds: [embed], components: [row] });
            message.delete();
        }
    });
    
    client.on('interactionCreate', async (interaction) => {
        if (!interaction.isButton()) return;
    
        if (interaction.customId === 'start-verification') {
            const code = Math.floor(1000 + Math.random() * 9000).toString();
            let enteredCode = '';
    
            const codeEmbed = new EmbedBuilder()
                .setAuthor({ name: `${config.ServerName} - Enter Code`, iconURL: config.ServerIcon })
                .setDescription(`**Enter This Code:** \n \`\`\`${code}\`\`\` \n **The Code You Entered:** \n \`\`\`None\`\`\``)
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp()
                .setColor('Green');
    
            const buttons = [];
            for (let i = 1; i <= 9; i++) {
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId(`digit-${i}`)
                        .setLabel(`${i}`)
                        .setStyle(ButtonStyle.Primary)
                );
            }
    
            const zeroButton = new ButtonBuilder()
                .setCustomId('digit-0')
                .setLabel('0')
                .setStyle(ButtonStyle.Primary);
    
            const xButton = new ButtonBuilder()
                .setCustomId('digit-x')
                .setLabel('❌')
                .setStyle(ButtonStyle.Danger);
    
            const yButton = new ButtonBuilder()
                .setCustomId('digit-y')
                .setLabel('✅')
                .setStyle(ButtonStyle.Success);
    
            const row1 = new ActionRowBuilder().addComponents(buttons[0], buttons[1], buttons[2], xButton);
            const row2 = new ActionRowBuilder().addComponents(buttons[3], buttons[4], buttons[5], buttons[6]);
            const row3 = new ActionRowBuilder().addComponents(buttons[7], buttons[8], zeroButton, yButton);
    
            const sentMessage = await interaction.reply({ embeds: [codeEmbed], components: [row1, row2, row3], fetchReply: true, ephemeral: true });
    
            const collector = sentMessage.createMessageComponentCollector({
                componentType: ComponentType.Button,
                time: 60000,
            });
    
            collector.on('collect', async (i) => {
                const digit = i.customId.split('-')[1];
    
                if (digit === 'x') {
                    enteredCode = enteredCode.slice(0, -1);
                } else if (digit === 'y') {
                    if (enteredCode === code) {
                        const roleId = config.MemberRoleId;
                        const member = interaction.guild.members.cache.get(interaction.user.id);
    
                        if (member) {
                            await member.roles.add(roleId);
                            await interaction.followUp({ content: `**You Are Now \`Verified\` On The Server**`, ephemeral: true });
                        } else {
                            await interaction.followUp({ content: `**Not Found Member Role...**`, ephemeral: true });
                        }
    
                        collector.stop();
                    } else {
                        await interaction.followUp({ content: `**Verification Failed. Incorrect Code...**`, ephemeral: true });
                    }
                } else {
                    enteredCode += `${digit}`;
                }
    
                const updatedEmbed = new EmbedBuilder()
                    .setAuthor({ name: `${config.ServerName} - Enter Code`, iconURL: config.ServerIcon })
                    .setDescription(`**Enter This Code:** \n \`\`\`${code}\`\`\` \n **The Code You Entered:** \n \`\`\`${enteredCode || 'None'}\`\`\``)
                    .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                    .setTimestamp()
                    .setColor('Green');
    
                await i.update({ embeds: [updatedEmbed], components: [row1, row2, row3] });
            });
    
            collector.on('end', async () => {
                if (enteredCode !== code) {
                    await interaction.followUp({ content: `**Verification Failed**`, ephemeral: true });
                }
            });
        }
    });
}