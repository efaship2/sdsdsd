const { ButtonStyle, ButtonBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, SelectMenuBuilder,  ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'verify') {
            const role = config.MemberRoleId;
            await interaction.member.roles.add(role);
    
            interaction.reply({ content: `**You Are Now \`Verified\` On The Server**`, ephemeral: true });
        }
    });
}