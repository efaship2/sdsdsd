const { ChannelType, UserSelectMenuBuilder, SlashCommandBuilder, StringSelectMenuOptionBuilder, StringSelectMenuBuilder, InteractionType, ButtonStyle, ButtonBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, SelectMenuBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType, AuditLogEvent, ComponentType } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildInvites, GatewayIntentBits.GuildPresences, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.DirectMessages, GatewayIntentBits.GuildPresences] }); 
const config = require('../config.js');
const fs = require('fs');
const path = require('path');

module.exports = (client) => {
    const guessTheNumber = require('../commands/Admin/guess-the-number.js');
    client.on('messageCreate', guessTheNumber.checkGuess);
}