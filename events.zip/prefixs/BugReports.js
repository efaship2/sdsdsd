const { EmbedBuilder, ButtonStyle, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const channelsData = JSON.parse(fs.readFileSync(path.join(__dirname, '../../bugReportChannels.json'), 'utf-8'));
const allowedChannelId2 = channelsData.BugReportChannel1;

module.exports = (client) => {
    client.on('messageCreate', (message) => {
        if (!config.BugReport) {
            return;
        }
        if (message.author.bot) return;
        if (message.channel.id !== allowedChannelId2) return;

        message.delete().catch(console.error);

        const embed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setDescription(`**הדיווח שלך נשלח בהצלחה לצוות התכנות שלנו |** <@${message.member.id}>`);

        message.channel.send({ embeds: [embed] });

        const content = message.content;
        const BugChannel = message.member.guild.channels.cache.get(channelsData.BugReportChannel2);
        
        const embed2 = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${config.ServerName} | New Bug Report!`, iconURL: config.ServerIcon })
            .setDescription(`\`\`\`${content}\`\`\``)
            .setTimestamp()
            .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
            .setThumbnail(config.ServerIcon)
            .addFields(
                { name: 'Member', value: `<@${message.member.id}>`, inline: true },
                { name: 'Bug Status', value: `Not Fixed`, inline: true },
            );

        const button111 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirmBugreport')
                    .setLabel('Confirm')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('sendToDevelopers')
                    .setLabel('Send to Developers')
                    .setStyle(ButtonStyle.Primary)
            );

        BugChannel.send({ embeds: [embed2], components: [button111] });
    });

    client.on('interactionCreate', async (interaction) => {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'confirmBugreport') {
            if (!interaction.member.roles.cache.has(config.DeveloperRoleId)) {
                return interaction.reply({ content: `**You Are Not Development Team...**`, ephemeral: true });
            }

            const originalMessage = interaction.message;

            const memberField = originalMessage.embeds[0].fields.find(field => field.name === 'Member');
            const bugField = originalMessage.embeds[0].fields.find(field => field.name === 'Bug Status');

            if (!memberField || !bugField) {
                console.error('Field not found in the embed message');
                return;
            }

            const reporterId = memberField.value.replace('<@', '').replace('>', '');

            const updatedEmbed = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setAuthor({ name: `${config.ServerName} | New Bug Report!`, iconURL: config.ServerIcon })
                .setDescription(`${originalMessage.embeds[0].description}`)
                .setTimestamp()
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setThumbnail(config.ServerIcon)
                .addFields(
                    { name: 'Member', value: `<@${reporterId}>`, inline: true },
                    { name: 'Bug Status', value: `Fixed`, inline: true },
                );

            const updatedButtonRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirmBugreport')
                        .setLabel('Confirm')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('sendToDevelopers')
                        .setLabel('Send to Developers')
                        .setStyle(ButtonStyle.Primary)
                );

            await originalMessage.edit({ embeds: [updatedEmbed], components: [updatedButtonRow] });

            const reporter = await interaction.guild.members.fetch(reporterId);
            const embed1 = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setAuthor({ name: `${config.ServerName} | New Bug Report!`, iconURL: config.ServerIcon })
                .setDescription(`**רצינו להודיע לך שהבאג שדיווחת עליו סודר! תודה רבה על הדיווח והמשך יום מהנה.**`)
                .setTimestamp()
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setThumbnail(config.ServerIcon);

            await reporter.send({ embeds: [embed1] });
            await interaction.reply({ content: `**Bug Report Confirmed.**`, ephemeral: true });

        } else if (interaction.customId === 'sendToDevelopers') {
            if (!interaction.member.roles.cache.has(config.DeveloperRoleId)) {
                return interaction.reply({ content: `**You Are Not Development Team...**`, ephemeral: true });
            }

            const developersRoleId = config.DeveloperRoleId;
            const developers = interaction.guild.roles.cache.get(developersRoleId).members;

            if (developers.size === 0) {
                await interaction.reply({ content: `**Not Found Developers...**`, ephemeral: true });
                return;
            }

            const embedMessage = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setDescription(`**דווח על באג חדש, נא לבדוק את החדר דיווח באגים ונשמח שתתקנו אותו.**`)
                .setTimestamp()
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon });

            for (const [_, developer] of developers) {
                await developer.send({ embeds: [embedMessage] });
            }

            const updatedButtonRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirmBugreport')
                        .setLabel('Confirm')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('sendToDevelopers')
                        .setLabel('Send to Developers')
                        .setStyle(ButtonStyle.Primary)
                );

            await interaction.message.edit({ components: [updatedButtonRow] });

            await interaction.reply({ content: '**Message Sent To Development Team.**', ephemeral: true });
        }
    });
};