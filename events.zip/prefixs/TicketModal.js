const { ChannelType, UserSelectMenuBuilder, SlashCommandBuilder, StringSelectMenuOptionBuilder, StringSelectMenuBuilder, InteractionType, ButtonStyle, ButtonBuilder, ActionRowBuilder, TextInputStyle, TextInputBuilder, SelectMenuBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType, AuditLogEvent, ComponentType } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildInvites, GatewayIntentBits.GuildPresences, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.DirectMessages, GatewayIntentBits.GuildPresences] }); 
const config = require('../config.js');
const fs = require('fs');
const path = require('path');

module.exports = (client) => {
client.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.customId === 'button') {
        try {

                const welcomeEmbed = new EmbedBuilder()
                .setColor('#9f9f9f')
                .setDescription('> **Checking if you have another ticket...**');
            
            await interaction.reply({
                embeds: [welcomeEmbed],
                ephemeral: true
            });
            
            const sanitizedUsername = interaction.user.tag.replace(/[^a-zA-Z0-9_-]/g, '');
            
            const ticketName = `ticket-${sanitizedUsername}`;
            
            const existingTickets = interaction.guild.channels.cache.filter(channel => channel.name === ticketName);
            
            const ticketChannel = existingTickets.first();
            const embedAlready = new EmbedBuilder()
                .setColor('#ee2f2f')
                .setDescription(`**> You already have a ticket | ${ticketChannel}**`);
            
            if (existingTickets.size > 0) {
                return await interaction.editReply({ embeds: [embedAlready], ephemeral: true });
            }

            setTimeout(async () => {
                const timeoutsFilePath = path.join(__dirname, '../../timeoutsTickets.json');

                const hasCooldown = (userId) => {
                    if (fs.existsSync(timeoutsFilePath)) {
                        const timeouts = JSON.parse(fs.readFileSync(timeoutsFilePath));
                        return timeouts[userId] ? timeouts[userId] > Date.now() : false;
                    }
                    return false;
                };
                
                const getRemainingTime = (userId) => {
                    const timeouts = JSON.parse(fs.readFileSync(timeoutsFilePath));
                    const timeoutEnd = timeouts[userId];
                    return timeoutEnd - Date.now();
                };
                
                const userId = interaction.user.id;
                const ticketCheckEmbed = new EmbedBuilder()
                    .setColor('#737373')
                    .setDescription('> **Checking if you have cooldown...**');
                
                await interaction.editReply({
                    embeds: [ticketCheckEmbed],
                    ephemeral: true
                });
                
                if (hasCooldown(userId)) {
                    const remainingTime = getRemainingTime(userId);
                    const embedTimeout = new EmbedBuilder()
                    .setColor('#ee2f2f')
                    .setDescription(`> **You have a cooldown for <t:${Math.floor(Date.now() / 1000) + Math.floor(remainingTime / 1000)}:R>.**`);
                
                    await interaction.editReply({ 
                        embeds: [embedTimeout],
                        ephemeral: true
                    });
                    return;
                }

                setTimeout(async () => {

                    const blockCheckEmbed = new EmbedBuilder()
                        .setColor('#d1376d')
                        .setDescription('> **Checking if you are blacklisted...**');

                    await interaction.editReply({
                        embeds: [blockCheckEmbed],
                        ephemeral: true
                    });

                    const member = interaction.guild.members.cache.get(interaction.user.id);

                    if (!member) {

                        const errorEmbed = new EmbedBuilder()
                            .setColor('#ee2f2f')
                            .setDescription('**Error. Please try again later.**');
                        
                        return await interaction.editReply({
                            embeds: [errorEmbed],
                            ephemeral: true
                        });
                    }

                    const blacklistRoleId = config.BlackListRoleId;

                    setTimeout(async () => {
                        if (member.roles.cache.has(blacklistRoleId)) {

                            const blacklistEmbed = new EmbedBuilder()
                                .setColor('#ee2f2f')
                                .setDescription('> **You have a blacklist to open ticket.**');

                            await interaction.editReply({
                                embeds: [blacklistEmbed],
                                ephemeral: true
                            });
                        } else {

                            const ticketCategories = JSON.parse(fs.readFileSync(path.join(__dirname, '../../ticketCategorys.json'), 'utf8'));
                            const row = new ActionRowBuilder().addComponents(
                                new SelectMenuBuilder()
                                    .setPlaceholder('Select Your Ticket Category')
                                    .setCustomId('ticket_creation')
                                    .addOptions(
                                        ticketCategories.categories.map((category, index) => ({
                                            value: `option${index + 1}`,
                                            label: category.name,
                                            description: category.description || undefined,
                                            emoji: category.emoji || undefined
                                        }))
                                    )
                            );

                            const selectMenuEmbed = new EmbedBuilder()
                                .setColor('#6fd7ff')
                                .setDescription('> **Select Your Ticket Category**')

                            await interaction.editReply({
                                embeds: [selectMenuEmbed],
                                components: [row],
                                ephemeral: true
                            });
                        }
                    }, 400);
                }, 400);
            }, 400);
        } catch (error) {
            console.error('Error handling interaction:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor('Red')
                .setDescription('**An error occurred while processing your request. Please try again later.**');

            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    }
});
}