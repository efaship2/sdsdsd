const { ButtonStyle, ButtonBuilder, ActionRowBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, MessageManager, Embed, Collection } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        if (!config.GetRole) {
            return;
        }
        if (message.content === `${config.PrefixsBot}getrole`) {
            if (!message.member.roles.cache.has(config.StaffRoleId)) {
                return message.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**` });
            }

            const embed = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setAuthor({ name: `${config.ServerName} | Get Roles`, iconURL: config.ServerIcon })
                .setDescription('**לחץ על הכפתור שתרצה לקבל עליו עדכונים.**')
                .setFooter({ text: `Developer: tzuri1`, iconURL: message.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

                const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Media Ping')
                        .setEmoji('<:7492nalike:1266677628287582268>')
                        .setStyle(ButtonStyle.Secondary)
                        .setCustomId('tzuri111111')
                )

            message.channel.send({ embeds: [embed], components: [button] });
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isButton()) return;

        const roles = {
            'tzuri111111': '1286330885121249385',
        };

        const roleId = roles[interaction.customId];
        if (!roleId) return;

        const member = interaction.member;

        if (member.roles.cache.has(roleId)) {
            await member.roles.remove(roleId);
            interaction.reply({ content: `❌ **| <@&${roleId}> Has Been Removed.**`, ephemeral: true });
        } else {
            await member.roles.add(roleId);
            interaction.reply({ content: `✅ **| <@&${roleId}> Has Been Received.**`, ephemeral: true });
        }
    });
};
