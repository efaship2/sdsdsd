const { AuditLogEvent, Events, EmbedBuilder } = require('discord.js');
const config = require('../config.js');
const fs = require('fs');
const path = require('path');

const logsChannelFilePath = path.join(__dirname, '../../logsChannel.json');

module.exports = (client) => {
    if (!config.MainLogs) return;

    let logsChannelData;
    try {
        logsChannelData = JSON.parse(fs.readFileSync(logsChannelFilePath, 'utf8'));
    } catch (error) {
        return;
    }

    const idchannel = logsChannelData.logsChannel;
    const CHANNEL_LOGS = idchannel;
    const LOG_CHANNELS = {
        logChannel111111: CHANNEL_LOGS,
    };

    if (!client.listenerCount(Events.ChannelCreate)) {
        client.on(Events.ChannelCreate, async channel => {
            const fetchedLogs = await channel.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.ChannelCreate
            });
            const creationLog = fetchedLogs.entries.first();

            const creator = creationLog ? creationLog.executor : 'Unknown';
            const channelType = channel.type === 2 ? '\`🔊 Voice Channel\`' : '\`💬 Text Channel\`';

            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle('\`🔎\` Tzuri Logs')
                .addFields(
                    { name: 'Action', value: `**Create Channel**`, inline: true },
                    { name: 'Channel', value: `**\`${channel.name}\` (${channel})**`, inline: true },
                    { name: 'Channel ID', value: `**\`${channel.id}\`**`, inline: true },
                    { name: 'Channel Type', value: `**\`${channelType}\`**`, inline: true },
                    { name: 'Created By', value: `**\`${creator.tag}\` (${creator})**`, inline: true },
                    { name: 'Created At', value: `**<t:${Math.floor(channel.createdAt.getTime() / 1000)}:R>**`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();

            const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
            if (logChannel) {
                logChannel.send({ embeds: [embed] });
            }
        });
    }

    if (!client.listenerCount(Events.ChannelDelete)) {
        client.on(Events.ChannelDelete, async channel => {
            const fetchedLogs = await channel.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.ChannelDelete
            });
            const creationLog = fetchedLogs.entries.first();

            const creator = creationLog ? creationLog.executor : 'Unknown';
            const channelType = channel.type === 2 ? '\`🔊 Voice Channel\`' : '\`💬 Text Channel\`';

            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle('\`🔎\` Tzuri Logs')
                .addFields(
                    { name: 'Action', value: `**Delete Channel**`, inline: true },
                    { name: 'Channel', value: `**\`${channel.name}\` (${channel})**`, inline: true },
                    { name: 'Channel ID', value: `**\`${channel.id}\`**`, inline: true },
                    { name: 'Channel Type', value: `**${channelType}**`, inline: true },
                    { name: 'Deleted By', value: `**\`${creator.tag}\` (${creator})**`, inline: true },
                    { name: 'Deleted At', value: `**<t:${Math.floor(channel.createdAt.getTime() / 1000)}:R>**`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();

            const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
            if (logChannel) {
                logChannel.send({ embeds: [embed] });
            }
        });
    }

    if (!client.listenerCount(Events.GuildRoleCreate)) {
        client.on(Events.GuildRoleCreate, async role => {
            const fetchedLogs = await role.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.RoleCreate
            });
            const creationLog = fetchedLogs.entries.first();

            const creator = creationLog ? creationLog.executor : 'Unknown';

            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle('\`🔎\` Tzuri Logs')
                .addFields(
                    { name: 'Action', value: `**Create Role**`, inline: true },
                    { name: 'Role', value: `**\`${role.name}\` (${role})**`, inline: true },
                    { name: 'Role ID', value: `**\`${role.id}\`**`, inline: true },
                    { name: 'Created By', value: `**\`${creator.tag}\` (${creator})**`, inline: true },
                    { name: 'Created At', value: `**<t:${Math.floor(role.createdAt.getTime() / 1000)}:R>**`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();

            const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
            if (logChannel) {
                logChannel.send({ embeds: [embed] });
            }
        });
    }

    if (!client.listenerCount(Events.GuildRoleDelete)) {
        client.on(Events.GuildRoleDelete, async role => {
            const fetchedLogs = await role.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.RoleDelete
            });
            const deletionLog = fetchedLogs.entries.first();

            const creator = deletionLog ? deletionLog.executor : 'Unknown';

            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle('\`🔎\` Tzuri Logs')
                .addFields(
                    { name: 'Action', value: `**Delete Role**`, inline: true },
                    { name: 'Name Role', value: `**\`${role.name}\`**`, inline: true },
                    { name: 'Deleted By', value: `**\`${creator.tag}\` (${creator})**`, inline: true },
                    { name: 'Role Created At', value: `**<t:${Math.floor(role.createdAt.getTime() / 1000)}:R>**`, inline: true },
                    { name: 'Deleted At', value: `**<t:${Math.floor(deletionLog.createdAt.getTime() / 1000)}:R>**`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();

                const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
                if (logChannel) {
                    logChannel.send({ embeds: [embed] });
                }
            });
        }

        if (!client.listenerCount(Events.MessageDelete)) {
            client.on(Events.MessageDelete, async message => {
                if (message.author.bot) return;
    
                const embed = new EmbedBuilder()
                    .setColor('Random')
                    .setTitle('\`🔎\` Tzuri Logs')
                    .addFields(
                        { name: 'Action', value: `**Delete Message**`, inline: true },
                        { name: 'Member', value: `**\`${message.author.tag}\` (${message.member})**`, inline: true },
                        { name: 'Channel', value: `**\`${message.channel.name}\` (<#${message.channel.id}>)**`, inline: true },
                        { name: 'Deleted At', value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`, inline: true },
                        { name: 'Message Content', value: `\`\`\`${message.content || 'No Content'}\`\`\``, inline: false },
                    )
                    .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                    .setTimestamp();
    
                    const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
                    if (logChannel) {
                        logChannel.send({ embeds: [embed] });
                    }
                });
            }

            if (client.listenerCount(Events.MessageUpdate)) {
                client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
                    try {
                        if (oldMessage.author.bot) return;
            
                        if (oldMessage.content !== newMessage.content) {
                            const embed = new EmbedBuilder()
                                .setColor('Random')
                                .setTitle('\`🔎\` Tzuri Logs')
                                .addFields(
                                    { name: 'Action', value: `**Edit Message**`, inline: true },
                                    { name: 'Member', value: `**\`${newMessage.author.tag}\` (${newMessage.member})**`, inline: true },
                                    { name: 'Channel', value: `**\`${newMessage.channel.name}\` (<#${newMessage.channel.id}>)**`, inline: true },
                                    { name: 'Edited At', value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`, inline: true },
                                    { name: 'Old Message', value: `\`\`\`${oldMessage.content || 'No Content'}\`\`\``, inline: false },
                                    { name: 'New Message', value: `\`\`\`${newMessage.content || 'No Content'}\`\`\``, inline: false },
                                )
                                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                                .setTimestamp();
            
                            const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
                            if (logChannel) {
                                logChannel.send({ embeds: [embed] });
                            } else {
                                console.log("Log channel not found!");
                            }
                        }
                    } catch (error) {
                        console.error("Error in MessageUpdate event:", error);
                    }
                });
            }

    if (!client.listenerCount(Events.GuildMemberAdd)) {
        client.on(Events.GuildMemberAdd, async member => {

            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle('\`🔎\` Tzuri Logs')
                .addFields(
                    { name: 'Action', value: `**Member Join**`, inline: true },
                    { name: 'Member', value: `**\`${member.user.tag}\` (${member})**`, inline: true },
                    { name: 'Member ID', value: `**\`${member.id}\`**`, inline: true },
                    { name: 'Account Created At', value: `**<t:${Math.floor(member.user.createdAt.getTime() / 1000)}>**`, inline: true },
                    { name: 'Joined At', value: `**<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>**`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();

            const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
            if (logChannel) {
                logChannel.send({ embeds: [embed] });
            }
        });
    }

    if (!client.listenerCount(Events.GuildMemberRemove)) {
        client.on(Events.GuildMemberRemove, async member => {

            const embed = new EmbedBuilder()
                .setColor('Random')
                .setTitle('\`🔎\` Tzuri Logs')
                .addFields(
                    { name: 'Action', value: `**Member Left**`, inline: true },
                    { name: 'Member', value: `**\`${member.user.tag}\` (${member})**`, inline: true },
                    { name: 'Member ID', value: `**\`${member.id}\`**`, inline: true },
                    { name: 'Account Created At', value: `**<t:${Math.floor(member.user.createdAt.getTime() / 1000)}>**`, inline: true },
                    { name: 'Joined Date', value: `**<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>**`, inline: true },
                    { name: 'Left At', value: `**<t:${Math.floor(Date.now() / 1000)}:R>**`, inline: true },
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();

            const logChannel = client.channels.cache.get(LOG_CHANNELS.logChannel111111);
            if (logChannel) {
                logChannel.send({ embeds: [embed] });
            }
        });
    }
};
