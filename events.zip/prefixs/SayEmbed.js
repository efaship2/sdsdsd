const { Client, GatewayIntentBits, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
const config = require('../config.js');

module.exports = (client) => {
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId === 'sayembed:modal') {
      const message = interaction.fields.getTextInputValue('sayembed:message');
      const title = interaction.fields.getTextInputValue('sayembed:title');
      const imageURL = interaction.fields.getTextInputValue('sayembed:imageURL') || null;
      const thumbnail = interaction.fields.getTextInputValue('sayembed:thumbnail') || null;

      const embed = new EmbedBuilder()
        .setColor(config.ServerColor)
        .setTitle(title)
        .setDescription(message)
        .setImage(imageURL ? imageURL : undefined)
        .setThumbnail(thumbnail ? thumbnail : undefined);

      await interaction.reply({ content: `**Message Was Sent Successfully.**`, ephemeral: true });
      await interaction.channel.send({ embeds: [embed] });
    }
  });
};