const { ButtonStyle, ButtonBuilder, ActionRowBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, MessageManager, Embed, Collection } = require(`discord.js`);
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');
const path = require('path');
const fs = require('fs');

const warnsPath = path.join(__dirname, '../../warns.json');

function loadWarns() {
    if (!fs.existsSync(warnsPath)) {
        fs.writeFileSync(warnsPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(warnsPath));
}

function saveWarns(warns) {
    fs.writeFileSync(warnsPath, JSON.stringify(warns, null, 2));
}

module.exports = (client) => {
    client.on(Events.MessageCreate, message => {
        if (!config.Warns) {
            return;
        }
        if (message.author.bot) return;
    
        const args = message.content.split(' ');
        const command = args[0];
        const userId = args[1]?.replace(/[^0-9]/g, '');
        const reason = args.slice(2).join(' ') || 'No Reason';
        const now = new Date();
        const timestamp = now.toISOString();
        const authorId = message.author.id;
    
        if (command === `${config.PrefixsBot}warn`) {
            if (!message.member.roles.cache.get(config.StaffRoleId)) {
                return message.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**`, ephemeral: true });
            }
    
            if (!userId) {
                return message.reply(`**Please Mention User**`);
            }
    
            const warns = loadWarns();
            if (!warns[userId]) {
                warns[userId] = { count: 0, details: [] };
            }
    
            warns[userId].count += 1;
            warns[userId].details.push({ reason, authorId, timestamp });
            saveWarns(warns);
    
            const embedWarning = new EmbedBuilder()
                .setColor('Red')
                .setAuthor({ name: `${config.ServerName} | Warning System`, iconURL: config.ServerIcon })
                .setDescription(`<@${userId}> **Has Warned By** ${message.member} \n\n **Reason:** \`\`\`${reason}\`\`\` \n **Time:** \n \`\`\`${now.toLocaleString()}\`\`\``)
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();
            message.reply({ embeds: [embedWarning] });
        } else if (command === `${config.PrefixsBot}checkwarns`) {
            if (!message.member.roles.cache.get(config.ManagementRoleID)) {
                return message.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**`, ephemeral: true });
            }
            
            if (!userId) {
                return message.reply(`**Please Mention User**`);
            }
    
            const warns = loadWarns();
            const userWarns = warns[userId] || { count: 0, details: [] };
    
            const reasonsList = userWarns.details.map(detail => {
                const author = `<@${detail.authorId}>`;
                const date = new Date(detail.timestamp).toLocaleString();
                return `**Reason:** \`${detail.reason}\` \n **Time:** \`${date}\` \n **Warned By:** ${author}`;
            }).join('\n\n');
    
            const embedCheckWarns = new EmbedBuilder()
                .setColor('Red')
                .setAuthor({ name: `${config.ServerName} | Warning System`, iconURL: config.ServerIcon })
                .setDescription(`**User:** <@${userId}> \n\n **Total Warns:** \n \`\`\`${userWarns.count}\`\`\` \n ${reasonsList}`)
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();
            message.reply({ embeds: [embedCheckWarns] });
        } else if (command === `${config.PrefixsBot}unwarn`) {
            if (!message.member.roles.cache.get(config.ManagementRoleID)) {
                return message.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**`, ephemeral: true });
            }
    
            if (!userId) {
                return message.reply(`**Please Mention User**`);
            }
    
            const warns = loadWarns();
            const userWarns = warns[userId];
    
            if (!userWarns || userWarns.count === 0) {
                return message.reply(`**This User Has No Warns To Remove**`);
            }
    
            userWarns.details.pop();
            userWarns.count -= 1;
    
            if (userWarns.count === 0) {
                delete warns[userId];
            }
    
            saveWarns(warns);
    
            const embedUnwarn = new EmbedBuilder()
                .setColor('Green')
                .setAuthor({ name: `${config.ServerName} | Warning System`, iconURL: config.ServerIcon })
                .setDescription(`<@${userId}> **Removed Last Warning By** ${message.member}`)
                .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
                .setTimestamp();
            message.reply({ embeds: [embedUnwarn] });
        }
    });
}