const fs = require('fs');
const {
    EmbedBuilder,
    ButtonBuilder,
    ActionRowBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
} = require('discord.js');
const config = require('../config.js');
const path = './suggestions.json';
const suggestionChannelPath = './suggestionChannel.json';

const loadChannelData = () => {
    if (fs.existsSync(suggestionChannelPath)) {
        const data = fs.readFileSync(suggestionChannelPath);
        return JSON.parse(data);
    }
    return {};
};

const createEmbed = (content, voteCounts, suggestionMember, comments = '') => {
    if (!config.Suggestion1) {
        return;
    }
    return new EmbedBuilder()
        .setColor(config.ServerColor)
        .setAuthor({ name: `${config.ServerName} - Suggestions`, iconURL: config.ServerIcon })
        .setDescription(`\`\`\`${content}\`\`\``)
        .addFields(
            { name: 'Member:', value: `${suggestionMember}`, inline: true },
            { name: 'Votes Status', value: `\`✅:\` **${voteCounts.yes} |** \`❌:\` **${voteCounts.no}**`, inline: true },
            { name: 'Comments:', value: comments.length > 0 ? comments : '**אין תגובות**', inline: false }
        )
        .setFooter({ text: `Developer: tzuri1`, iconURL: config.ServerIcon })
        .setThumbnail(config.ServerIcon)
        .setTimestamp();
};

module.exports = (client) => {
    const loadData = () => {
        if (fs.existsSync(path)) {
            const data = fs.readFileSync(path);
            return JSON.parse(data);
        }
        return {};
    };

    const saveData = (data) => {
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
    };

    const suggestionData = loadData();
    const channelData = loadChannelData();

    client.once('ready', () => {
        client.guilds.cache.forEach(guild => {
            const allowedChannelId = channelData[guild.id];
            if (!allowedChannelId) return;

            const channel = guild.channels.cache.get(allowedChannelId);
            if (channel) {
                channel.messages.fetch().then((messages) => {
                    messages.forEach((message) => {
                        if (suggestionData[message.id]) {
                            const suggestion = suggestionData[message.id];
                            const collector = message.createMessageComponentCollector({ time: 24 * 60 * 60 * 1000 });
                            handleCollector(collector, suggestion, message);
                        }
                    });
                });
            }
        });
    });

    client.on('messageCreate', async (message) => {
        if (!config.Suggestion1) return;
        if (message.author.bot) return;

        const allowedChannelId = channelData[message.guild.id];
        if (!allowedChannelId || message.channel.id !== allowedChannelId) return;

        message.delete().catch(console.error);
        const content = message.content.trim();

        const voteCounts = { yes: 0, no: 0 };
        const userVotes = {};
        const suggestionMember = message.member.toString();
        const comments = '';

        const voteUpButton = new ButtonBuilder().setCustomId('vote_up').setLabel('Yes').setStyle(ButtonStyle.Success);
        const voteDownButton = new ButtonBuilder().setCustomId('vote_down').setLabel('No').setStyle(ButtonStyle.Danger);
        const commentButton = new ButtonBuilder().setCustomId('give_comment').setLabel('Give Comment').setStyle(ButtonStyle.Primary);
        const listButton = new ButtonBuilder().setCustomId('list_votes').setLabel('Show Votes').setStyle(ButtonStyle.Secondary);
        const closeButton = new ButtonBuilder().setCustomId('toggle_close').setLabel('Close Suggestion').setStyle(ButtonStyle.Secondary);

        const actionRow = new ActionRowBuilder().addComponents(voteUpButton, voteDownButton, commentButton, listButton, closeButton);

        const suggestionMessage = await message.channel.send({ embeds: [createEmbed(content, voteCounts, suggestionMember, comments)], components: [actionRow] });
        suggestionData[suggestionMessage.id] = {
            content,
            voteCounts,
            userVotes,
            comments: [],
            member: suggestionMember,
            closed: false,
            commentUsers: [],
        };
        saveData(suggestionData);

        const collector = suggestionMessage.createMessageComponentCollector({ time: 24 * 60 * 60 * 1000 });
        handleCollector(collector, suggestionData[suggestionMessage.id], suggestionMessage);
    });

    const handleCollector = (collector, suggestion, suggestionMessage) => {
        collector.on('collect', async (interaction) => {
            const userId = interaction.user.id;

            if (interaction.customId === 'vote_up' || interaction.customId === 'vote_down') {
                handleVoting(interaction, suggestion, userId, suggestionMessage);
            } else if (interaction.customId === 'list_votes') {
                handleVoteList(interaction, suggestion);
            } else if (interaction.customId === 'toggle_close') {
                handleToggleClose(interaction, suggestionMessage);
            } else if (interaction.customId === 'give_comment') {
                handleComment(interaction, suggestion, suggestionMessage);
            }
        });
    };

    const handleVoting = async (interaction, suggestion, userId, suggestionMessage) => {
        if (interaction.customId === 'vote_up') {
            if (suggestion.userVotes[userId] === 'yes') {
                await interaction.reply({ content: '**You Have Already Voted Yes.**', ephemeral: true });
                return;
            } else if (suggestion.userVotes[userId] === 'no') {
                suggestion.voteCounts.no--;
                suggestion.voteCounts.yes++;
                suggestion.userVotes[userId] = 'yes';
            } else {
                suggestion.voteCounts.yes++;
                suggestion.userVotes[userId] = 'yes';
            }
        } else if (interaction.customId === 'vote_down') {
            if (suggestion.userVotes[userId] === 'no') {
                await interaction.reply({ content: '**You Have Already Voted No.**', ephemeral: true });
                return;
            } else if (suggestion.userVotes[userId] === 'yes') {
                suggestion.voteCounts.yes--;
                suggestion.voteCounts.no++;
                suggestion.userVotes[userId] = 'no';
            } else {
                suggestion.voteCounts.no++;
                suggestion.userVotes[userId] = 'no';
            }
        }

        await interaction.deferUpdate();
        await interaction.followUp({ content: '**You Voted Successfully!**', ephemeral: true });
        suggestionMessage.edit({ embeds: [createEmbed(suggestion.content, suggestion.voteCounts, suggestion.member, suggestion.comments.join('\n'))] }).catch(console.error);
        saveData(suggestionData);
    };

    const handleVoteList = async (interaction, suggestion) => {
        const yesVoters = Object.keys(suggestion.userVotes).filter((id) => suggestion.userVotes[id] === 'yes').map((id) => `<@${id}>`).join('\n') || 'None';
        const noVoters = Object.keys(suggestion.userVotes).filter((id) => suggestion.userVotes[id] === 'no').map((id) => `<@${id}>`).join('\n') || 'None';

        const listEmbed = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setTitle(`${config.ServerName} - List Votes`)
            .addFields(
                { name: '\`✅:\`', value: yesVoters, inline: true },
                { name: '\`❌:\`', value: noVoters, inline: true }
            );

        await interaction.reply({ embeds: [listEmbed], ephemeral: true });
    };

    const handleToggleClose = async (interaction, suggestionMessage) => {
        const isOpen = interaction.component.label === 'Open Suggestion';

        const updatedButtons = suggestionMessage.components[0].components.map((button) => {
            if (button.customId === 'vote_up' || button.customId === 'vote_down' || button.customId === 'give_comment') {
                return ButtonBuilder.from(button).setDisabled(!isOpen);
            } else if (button.customId === 'toggle_close') {
                return ButtonBuilder.from(button)
                    .setLabel(isOpen ? 'Close Suggestion' : 'Open Suggestion')
                    .setStyle(ButtonStyle.Secondary);
            }
            return ButtonBuilder.from(button);
        });

        const updatedRow = new ActionRowBuilder().addComponents(...updatedButtons);
        await interaction.update({ components: [updatedRow] });
    };

    const handleComment = async (interaction, suggestion, suggestionMessage) => {
        const userId = interaction.user.id;

        if (suggestion.commentUsers.includes(userId)) {
            await interaction.reply({ content: '**You Have Already Commented On This Suggestion.**', ephemeral: true });
            return;
        }

        const modal = new ModalBuilder()
            .setCustomId('comment_modal')
            .setTitle('Give Comment')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('comment_input')
                        .setLabel('Enter your comment')
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);

        const filter = (i) => i.customId === 'comment_modal';
        const modalInteraction = await interaction.awaitModalSubmit({ filter, time: 60 * 1000 }).catch(() => null);

        if (!modalInteraction) {
            return;
        }

        const comment = modalInteraction.fields.getTextInputValue('comment_input');
        suggestion.comments.push(`**${interaction.user}:** ${comment}`);
        suggestion.commentUsers.push(userId);

        await modalInteraction.reply({ content: '**Your Comment Has Been Added!**', ephemeral: true });
        suggestionMessage.edit({ embeds: [createEmbed(suggestion.content, suggestion.voteCounts, suggestion.member, suggestion.comments.join('\n'))] }).catch(console.error);
        saveData(suggestionData);
    };
};
