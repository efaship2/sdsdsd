const { ChannelType, RoleSelectMenuBuilder, TextInputStyle, UserSelectMenuBuilder, TextInputBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder, ModalBuilder, Events, Client, GatewayIntentBits, EmbedBuilder, MessageManager, Embed, Collection } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] }); 
const config = require('../config.js');

module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        if (!config.Adminmenu) {
            return;
        }
        if (message.content === `${config.PrefixsBot}adminmenu`) {
            if (!message.member.roles.cache.has(config.ManagementRoleID)) {
                return message.reply({ content: `**You Do Not Have The Required Permissions To Use This Command.**` });
            }

            const embed = new EmbedBuilder()
                .setColor(config.ServerColor)
                .setAuthor({ name: `${message.guild.name} - Admin Menu`, iconURL: message.guild.iconURL({ dynamic: true })})
                .setDescription(
                    `
__Welcome To Admin Menu:__
* **Ban Member**
* **Unban Member**
* **Kick Member**
* **Timeout Member**
* **Remove Timeout Member**
* **Take Role**
* **Remove Role**         
* **Clear Messages**
* **Send Direct Messages (DM)**
* **Lock Channel**
* **Unlock Channel**    
* **Say Message** 
                    `
                )
                .setFooter({ text: `Developer: tzuri1`, iconURL: message.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Ban')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:banmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Unban')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:unbanmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Kick')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:kickmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Timeout')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:timeoutmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Remove Timeout')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:removetimeoutmember')
                )

                const button2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Take Role')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:takerole')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Remove Role')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:removerole')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Clear Messages')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:clearmessages')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Direct Message (DM)')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:directmessage')
                )

                const button3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Lock Channel')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:lockedchannel')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Unlock Channel')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:unlockedchannel')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Say Message')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:saymessages')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Close Menu')
                        .setStyle(ButtonStyle.Danger)
                        .setCustomId('adminmenu:closemenu')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Open Menu')
                        .setStyle(ButtonStyle.Success)
                        .setCustomId('adminmenu:openmenu')
                )

            message.channel.send({ embeds: [embed], components: [button, button2, button3] });
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isButton()) return;
    
        if (interaction.customId === 'adminmenu:closemenu') {
            const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Ban')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:banmember')
                        .setDisabled(true)
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Unban')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:unbanmember')
                        .setDisabled(true)
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Kick')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true)
                        .setCustomId('adminmenu:kickmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Timeout')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true)
                        .setCustomId('adminmenu:timeoutmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Remove Timeout')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:removetimeoutmember')
                )

                const button2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Take Role')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true)
                        .setCustomId('adminmenu:takerole')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Remove Role')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:removerole')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Clear Messages')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:clearmessages')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Direct Message (DM)')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:directmessage')
                )

                const button3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Lock Channel')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:lockedchannel')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Unlock Channel')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:unlockedchannel')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Say Message')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:saymessages')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Close Menu')
                        .setDisabled(true)
                        .setStyle(ButtonStyle.Danger)
                        .setCustomId('adminmenu:closemenu')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Open Menu')
                        .setStyle(ButtonStyle.Success)
                        .setCustomId('adminmenu:openmenu')
                )

            const embed33 = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true })})
            .setDescription(
                `
__Welcome To Admin Menu:__
* **Ban Member**
* **Unban Member**
* **Kick Member**
* **Timeout Member**
* **Remove Timeout Member**
* **Take Role**
* **Remove Role**         
* **Clear Messages**
* **Send Direct Messages (DM)**
* **Lock Channel**
* **Unlock Channel**    
* **Say Message** 

> **__Status:__ Close**
                `
            )
            .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp();
    
            await interaction.update({
                embeds: [embed33],
                components: [button, button2, button3],
            });
    
        } else if (interaction.customId === 'adminmenu:openmenu') {
            const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Ban')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:banmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Unban')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:unbanmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Kick')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:kickmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Timeout')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:timeoutmember')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Remove Timeout')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:removetimeoutmember')
                )

                const button2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Take Role')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:takerole')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Remove Role')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:removerole')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Clear Messages')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:clearmessages')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Direct Message (DM)')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:directmessage')
                )

                const button3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Lock Channel')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:lockedchannel')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Unlock Channel')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:unlockedchannel')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Say Message')
                        .setStyle(ButtonStyle.Primary)
                        .setCustomId('adminmenu:saymessages')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Close Menu')
                        .setStyle(ButtonStyle.Danger)
                        .setCustomId('adminmenu:closemenu')
                )
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Open Menu')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(true)
                        .setCustomId('adminmenu:openmenu')
                )

            const embed333 = new EmbedBuilder()
            .setColor(config.ServerColor)
            .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true })})
            .setDescription(
                `
__Welcome To Admin Menu:__
* **Ban Member**
* **Unban Member**
* **Kick Member**
* **Timeout Member**
* **Remove Timeout Member**
* **Take Role**
* **Remove Role**         
* **Clear Messages**
* **Send Direct Messages (DM)**
* **Lock Channel**
* **Unlock Channel**    
* **Say Message** 

> **__Status:__ Open**
                `
            )
            .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp();
    
            await interaction.update({
                embeds: [embed333],
                components: [button, button2, button3],
            });
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton()) {
            if (interaction.customId === 'adminmenu:banmember') {
                const modal = new ModalBuilder()
                    .setCustomId('banModal')
                    .setTitle('Ban Member');
    
                const userIdInput = new TextInputBuilder()
                    .setCustomId('userId')
                    .setLabel("Discord ID")
                    .setStyle(TextInputStyle.Short);
    
                const reasonInput = new TextInputBuilder()
                    .setCustomId('banReason')
                    .setLabel("Reason")
                    .setStyle(TextInputStyle.Paragraph);
    
                const actionRow1 = new ActionRowBuilder().addComponents(userIdInput);
                const actionRow2 = new ActionRowBuilder().addComponents(reasonInput);
    
                modal.addComponents(actionRow1, actionRow2);
                await interaction.showModal(modal);
            }
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'banModal') {
            const userId = interaction.fields.getTextInputValue('userId');
            const reason = interaction.fields.getTextInputValue('banReason');
    
            try {
                const member = await interaction.guild.members.fetch(userId);
                await member.ban({ reason });
                await interaction.reply({ content: `<@${userId}> **Banned By ${interaction.user} Reason \`${reason}\`**`, ephemeral: true });
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                .setColor('Red')
                .setAuthor({ name: `${config.ServerName} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true })})
                .addFields(
                    { name: `Action`, value: `Ban Member`, inline: true },
                    { name: `Banned By`, value: `${interaction.user}`, inline: true },
                    { name: `Member Banned`, value: `<@${userId}>`, inline: true },
                    { name: `Reason`, value: `${reason}`, inline: true },
                )
                .setTimestamp()
                .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });

                logChannel.send({ embeds: [embedLogs] });
            } catch (error) {
                await interaction.reply({ content: `**Failed To Ban User: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.customId === 'adminmenu:unbanmember') {
            const modal = new ModalBuilder()
                .setCustomId('unbanModal')
                .setTitle('Unban Member');
    
            const userIdInput = new TextInputBuilder()
                .setCustomId('unbanUserId')
                .setLabel("Discord ID")
                .setStyle(TextInputStyle.Short);
    
            const actionRow1 = new ActionRowBuilder().addComponents(userIdInput);
            modal.addComponents(actionRow1);
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'unbanModal') {
            const userId = interaction.fields.getTextInputValue('unbanUserId');
    
            try {
                await interaction.guild.members.unban(userId);
                await interaction.reply({ content: `<@${userId}> **Unbanned By ${interaction.user}**`, ephemeral: true });
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${config.ServerName} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Unban Member`, inline: true },
                        { name: `Unbanned By`, value: `${interaction.user}`, inline: true },
                        { name: `Member Unbanned`, value: `<@${userId}>`, inline: true },
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
            } catch (error) {
                await interaction.reply({ content: `**Failed To Unban User: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.customId === 'adminmenu:kickmember') {
            const modal = new ModalBuilder()
                .setCustomId('kickModal')
                .setTitle('Kick Member');

            const userIdInput = new TextInputBuilder()
                .setCustomId('kickUserId')
                .setLabel("Discord ID")
                .setStyle(TextInputStyle.Short);

            const reasonInput = new TextInputBuilder()
                .setCustomId('kickReason')
                .setLabel("Reason")
                .setStyle(TextInputStyle.Paragraph);

            const actionRow1 = new ActionRowBuilder().addComponents(userIdInput);
            const actionRow2 = new ActionRowBuilder().addComponents(reasonInput);

            modal.addComponents(actionRow1, actionRow2);
            await interaction.showModal(modal);
        }

    if (interaction.isModalSubmit() && interaction.customId === 'kickModal') {
            const userId = interaction.fields.getTextInputValue('kickUserId');
            const reason = interaction.fields.getTextInputValue('kickReason');
    
            try {
                const member = await interaction.guild.members.fetch(userId);
                await member.kick(reason);
                await interaction.reply({ content: `<@${userId}> **Kicked By ${interaction.user} Reason \`${reason}\`**`, ephemeral: true });
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${config.ServerName} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Kick Member`, inline: true },
                        { name: `Kicked By`, value: `${interaction.user}`, inline: true },
                        { name: `Member Kicked`, value: `<@${userId}>`, inline: true },
                        { name: `Reason`, value: `${reason}`, inline: true },
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
            } catch (error) {
                await interaction.reply({ content: `**Failed To Kick User: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:timeoutmember') {
            const modal = new ModalBuilder()
                .setCustomId('timeoutModal')
                .setTitle('Timeout Member');
    
            const userIdInput = new TextInputBuilder()
                .setCustomId('targetUserId')
                .setLabel("Discord ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const durationInput = new TextInputBuilder()
                .setCustomId('timeoutDuration')
                .setLabel("Timeout Duration (Minutes)")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const reasonInput = new TextInputBuilder()
                .setCustomId('timeoutReason')
                .setLabel("Reason")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(false);
    
            const actionRow1 = new ActionRowBuilder().addComponents(userIdInput);
            const actionRow2 = new ActionRowBuilder().addComponents(durationInput);
            const actionRow3 = new ActionRowBuilder().addComponents(reasonInput);
    
            modal.addComponents(actionRow1, actionRow2, actionRow3);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'timeoutModal') {
            const targetUserId = interaction.fields.getTextInputValue('targetUserId');
            const duration = parseInt(interaction.fields.getTextInputValue('timeoutDuration'));
            const reason = interaction.fields.getTextInputValue('timeoutReason') || 'No Reason';
    
            if (isNaN(duration) || duration <= 0) {
                await interaction.reply({ content: `> **Invalid timeout duration provided. Please enter a valid number of minutes.**`, ephemeral: true });
                return;
            }
    
            const timeoutDuration = duration * 60 * 1000;
    
            try {
                const member = await interaction.guild.members.fetch(targetUserId);
                
                if (!member) {
                    await interaction.reply({ content: `> **Discord ID Is Not Defined.**`, ephemeral: true });
                    return;
                }
    
                if (member.communicationDisabledUntilTimestamp && member.communicationDisabledUntilTimestamp > Date.now()) {
                    await interaction.reply({ content: `> <@${member.id}> **is already in timeout. Please check the timeout duration.**`, ephemeral: true });
                    return;
                }
    
                await member.timeout(timeoutDuration, reason);
                await interaction.reply({ content: `> <@${member.id}> **Has Been Timed Out For \`${duration} Minutes\`. Reason: \`${reason}\`.**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Timeout Member`, inline: true },
                        { name: `Timed Out By`, value: `${interaction.user}`, inline: true },
                        { name: `Member Timed Out`, value: `<@${member.id}>`, inline: true },
                        { name: `Duration`, value: `${duration} Minutes`, inline: true },
                        { name: `Reason`, value: `${reason}`, inline: true },
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
            } catch (error) {
                await interaction.reply({ content: `**Failed to apply timeout: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:removetimeoutmember') {
            const modal = new ModalBuilder()
                .setCustomId('removeTimeoutModal')
                .setTitle('Remove Timeout');
    
            const userIdInput = new TextInputBuilder()
                .setCustomId('targetUserId')
                .setLabel("Discord ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const reasonInput = new TextInputBuilder()
                .setCustomId('timeoutRemoveReason')
                .setLabel("Reason (Optional)")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(false);
    
            const actionRow1 = new ActionRowBuilder().addComponents(userIdInput);
            const actionRow2 = new ActionRowBuilder().addComponents(reasonInput);
    
            modal.addComponents(actionRow1, actionRow2);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'removeTimeoutModal') {
            const targetUserId = interaction.fields.getTextInputValue('targetUserId');
            const reason = interaction.fields.getTextInputValue('timeoutRemoveReason') || 'No Reason Provided';
    
            try {
                const member = await interaction.guild.members.fetch(targetUserId);
    
                if (!member) {
                    await interaction.reply({ content: `> **Invalid Discord ID Provided.**`, ephemeral: true });
                    return;
                }
    
                if (!member.communicationDisabledUntilTimestamp || member.communicationDisabledUntilTimestamp < Date.now()) {
                    await interaction.reply({ content: `> <@${member.id}> **Is Not Currently Timed Out.**`, ephemeral: true });
                    return;
                }
    
                await member.timeout(null, reason);
                await interaction.reply({ content: `> <@${member.id}> **Has Had Their Timeout Removed. Reason: \`${reason}\`.**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Remove Timeout`, inline: true },
                        { name: `Removed By`, value: `${interaction.user}`, inline: true },
                        { name: `Member`, value: `<@${member.id}>`, inline: true },
                        { name: `Reason`, value: `${reason}`, inline: true },
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
            } catch (error) {
                await interaction.reply({ content: `**Failed to remove timeout: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });
    
    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:takerole') {
            const roleMenu = new RoleSelectMenuBuilder()
                .setCustomId('roleSelect')
                .setPlaceholder('Select a role...')
                .setMinValues(1)
                .setMaxValues(1);
    
            const roleRow = new ActionRowBuilder().addComponents(roleMenu);
    
            await interaction.reply({ components: [roleRow], ephemeral: true });
        }
    
        if (interaction.isRoleSelectMenu() && interaction.customId === 'roleSelect') {
            const selectedRole = interaction.values[0];
            const member = interaction.member;
    
            if (member.roles.cache.has(selectedRole)) {
                await interaction.reply({ content: `> **You Already Have The Role <@&${selectedRole}>.**`, ephemeral: true });
            } else {
                try {
                    await member.roles.add(selectedRole);
                    await interaction.reply({ content: `> **Successfully Take The Role <@&${selectedRole}> To <@${member.id}>.**`, ephemeral: true });
    
                    const logChannel = client.channels.cache.get('1292640762705739848');
                    const embedLogs = new EmbedBuilder()
                        .setColor('Red')
                        .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                        .addFields(
                            { name: `Action`, value: `Take Role`, inline: true },
                            { name: `Taked By`, value: `${interaction.user}`, inline: true },
                            { name: `Role Taked`, value: `<@&${selectedRole}>`, inline: true },
                        )
                        .setTimestamp()
                        .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                    logChannel.send({ embeds: [embedLogs] });
                } catch (error) {
                    await interaction.reply({ content: `**Failed to take the role: \`${error.message}\`**`, ephemeral: true });
                }
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:removerole') {
            const roleMenu = new RoleSelectMenuBuilder()
                .setCustomId('roleRemoveSelect')
                .setPlaceholder('Select a role...')
                .setMinValues(1)
                .setMaxValues(1);
    
            const roleRow = new ActionRowBuilder().addComponents(roleMenu);
    
            await interaction.reply({ components: [roleRow], ephemeral: true });
        }
    
        if (interaction.isRoleSelectMenu() && interaction.customId === 'roleRemoveSelect') {
            const selectedRole = interaction.values[0];
            const member = interaction.member;
    
            if (!member.roles.cache.has(selectedRole)) {
                await interaction.reply({ content: `> **You Do Not Have The Role <@&${selectedRole}>.**`, ephemeral: true });
            } else {
                try {
                    await member.roles.remove(selectedRole);
                    await interaction.reply({ content: `> **Successfully Removed The Role <@&${selectedRole}> From <@${member.id}>.**`, ephemeral: true });
    
                    const logChannel = client.channels.cache.get('1292640762705739848');
                    const embedLogs = new EmbedBuilder()
                        .setColor('Red')
                        .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                        .addFields(
                            { name: `Action`, value: `Remove Role`, inline: true },
                            { name: `Removed By`, value: `${interaction.user}`, inline: true },
                            { name: `Role Removed`, value: `<@&${selectedRole}>`, inline: true },
                        )
                        .setTimestamp()
                        .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                    logChannel.send({ embeds: [embedLogs] });
                } catch (error) {
                    await interaction.reply({ content: `**Failed to remove the role: \`${error.message}\`**`, ephemeral: true });
                }
            }
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:clearmessages') {
            const modal = new ModalBuilder()
                .setCustomId('clearMessagesModal')
                .setTitle('Clear Messages');
    
            const channelIdInput = new TextInputBuilder()
                .setCustomId('targetChannelId')
                .setLabel("Channel ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const numberOfMessagesInput = new TextInputBuilder()
                .setCustomId('numberOfMessages')
                .setLabel("Number Of Messages To Delete")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const actionRow1 = new ActionRowBuilder().addComponents(channelIdInput);
            const actionRow2 = new ActionRowBuilder().addComponents(numberOfMessagesInput);
    
            modal.addComponents(actionRow1, actionRow2);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'clearMessagesModal') {
            const targetChannelId = interaction.fields.getTextInputValue('targetChannelId');
            const numberOfMessages = parseInt(interaction.fields.getTextInputValue('numberOfMessages'));
    
            if (isNaN(numberOfMessages) || numberOfMessages <= 0 || numberOfMessages > 100) {
                await interaction.reply({ content: `> **Please Enter a Valid Number Between 1-100.**`, ephemeral: true });
                return;
            }
    
            try {
                const targetChannel = await interaction.guild.channels.fetch(targetChannelId);
    
                if (!targetChannel || !targetChannel.isTextBased()) {
                    await interaction.reply({ content: `> **Invalid Channel ID Provided**`, ephemeral: true });
                    return;
                }
    
                const fetchedMessages = await targetChannel.bulkDelete(numberOfMessages, true);
    
                await interaction.reply({ content: `> **Successfully Deleted \`${fetchedMessages.size}\` Messages From <#${targetChannel.id}>.**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Clear Messages`, inline: true },
                        { name: `Cleared By`, value: `${interaction.user}`, inline: true },
                        { name: `Channel`, value: `<#${targetChannel.id}>`, inline: true },
                        { name: `Number Of Messages Deleted`, value: `${fetchedMessages.size}`, inline: true },
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
            } catch (error) {
                await interaction.reply({ content: `**Failed to delete messages: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });    

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:directmessage') {
            const modal = new ModalBuilder()
                .setCustomId('directMessageModal')
                .setTitle('Direct Message (DM)');
    
            const userIdInput = new TextInputBuilder()
                .setCustomId('targetUserId')
                .setLabel("Discord ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const messageInput = new TextInputBuilder()
                .setCustomId('directMessageContent')
                .setLabel("Message")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);
    
            const actionRow1 = new ActionRowBuilder().addComponents(userIdInput);
            const actionRow2 = new ActionRowBuilder().addComponents(messageInput);
    
            modal.addComponents(actionRow1, actionRow2);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'directMessageModal') {
            const targetUserId = interaction.fields.getTextInputValue('targetUserId');
            const messageContent = interaction.fields.getTextInputValue('directMessageContent');
    
            try {
                const user = await client.users.fetch(targetUserId);
    
                await user.send({ content: messageContent });
    
                await interaction.reply({ content: `> **The Message Has Been Successfully Sent To <@${user.id}>.**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Direct Message (DM)`, inline: true },
                        { name: `Sent By`, value: `${interaction.user}`, inline: true },
                        { name: `Message Sent To`, value: `<@${user.id}>`, inline: true },
                        { name: `Message Content`, value: `${messageContent}`, inline: false },
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
    
            } catch (error) {
                await interaction.reply({ content: `> **Failed to send the message: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });    

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:lockedchannel') {
            const modal = new ModalBuilder()
                .setCustomId('lockedChannelModal')
                .setTitle('Lock Channel');
    
            const channelIdInput = new TextInputBuilder()
                .setCustomId('targetChannelId')
                .setLabel("Channel ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const actionRow = new ActionRowBuilder().addComponents(channelIdInput);
            modal.addComponents(actionRow);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'lockedChannelModal') {
            const targetChannelId = interaction.fields.getTextInputValue('targetChannelId');
    
            try {
                const channel = await interaction.guild.channels.fetch(targetChannelId);
    
                if (!channel) {
                    await interaction.reply({ content: `> **Channel ID Is Not defined.**`, ephemeral: true });
                    return;
                }
    
                await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                    ViewChannel: true,
                    SendMessages: false,
                });
    
                await interaction.reply({ content: `> **The Channel <#${channel.id}> Has Been Successfully Locked!**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Lock Channel`, inline: true },
                        { name: `Locked By`, value: `${interaction.user}`, inline: true },
                        { name: `Channel Locked`, value: `<#${channel.id}>`, inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
    
            } catch (error) {
                await interaction.reply({ content: `> **Failed to lock the channel: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });    

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:unlockedchannel') {
            const modal = new ModalBuilder()
                .setCustomId('unlockedChannelModal')
                .setTitle('Unlock Channel');
    
            const channelIdInput = new TextInputBuilder()
                .setCustomId('targetChannelId')
                .setLabel("Channel ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const actionRow = new ActionRowBuilder().addComponents(channelIdInput);
            modal.addComponents(actionRow);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'unlockedChannelModal') {
            const targetChannelId = interaction.fields.getTextInputValue('targetChannelId');
    
            try {
                const channel = await interaction.guild.channels.fetch(targetChannelId);
    
                if (!channel) {
                    await interaction.reply({ content: `> **Channel ID Is Not Defined.**`, ephemeral: true });
                    return;
                }
    
                await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                    ViewChannel: true,
                    SendMessages: true,
                });
    
                await interaction.reply({ content: `> **The Channel <#${channel.id}> Has Been Successfully Unlocked.**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Unlock Channel`, inline: true },
                        { name: `Unlocked By`, value: `${interaction.user}`, inline: true },
                        { name: `Channel Unlocked`, value: `<#${channel.id}>`, inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
    
            } catch (error) {
                await interaction.reply({ content: `> **Failed to unlock the channel: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });    

    client.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'adminmenu:saymessages') {
            const modal = new ModalBuilder()
                .setCustomId('sayMessagesModal')
                .setTitle('Say Message');
    
            const channelIdInput = new TextInputBuilder()
                .setCustomId('targetChannelId')
                .setLabel("Channel ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
    
            const messageInput = new TextInputBuilder()
                .setCustomId('messageContent')
                .setLabel("Message")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);
    
            const actionRowChannel = new ActionRowBuilder().addComponents(channelIdInput);
            const actionRowMessage = new ActionRowBuilder().addComponents(messageInput);
            modal.addComponents(actionRowChannel, actionRowMessage);
    
            await interaction.showModal(modal);
        }
    
        if (interaction.isModalSubmit() && interaction.customId === 'sayMessagesModal') {
            const targetChannelId = interaction.fields.getTextInputValue('targetChannelId');
            const messageContent = interaction.fields.getTextInputValue('messageContent');
    
            try {
                const channel = await interaction.guild.channels.fetch(targetChannelId);
    
                if (!channel || channel.type !== ChannelType.GuildText) {
                    await interaction.reply({ content: `> **Channel ID Is Not Defined or Not a Text Channel.**`, ephemeral: true });
                    return;
                }
    
                await channel.send(messageContent);
                await interaction.reply({ content: `> **Message Sent To <#${channel.id}> Successfully.**`, ephemeral: true });
    
                const logChannel = client.channels.cache.get('1292640762705739848');
                const embedLogs = new EmbedBuilder()
                    .setColor('Red')
                    .setAuthor({ name: `${interaction.guild.name} - Admin Menu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .addFields(
                        { name: `Action`, value: `Say Message`, inline: true },
                        { name: `Sent By`, value: `${interaction.user}`, inline: true },
                        { name: `Channel`, value: `<#${channel.id}>`, inline: true },
                        { name: `Message`, value: `${messageContent}`, inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Developer: tzuri1`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
    
                logChannel.send({ embeds: [embedLogs] });
    
            } catch (error) {
                await interaction.reply({ content: `> **Failed to send message: \`${error.message}\`**`, ephemeral: true });
            }
        }
    });
};